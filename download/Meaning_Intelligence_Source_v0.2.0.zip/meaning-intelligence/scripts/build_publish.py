# -*- coding: utf-8 -*-
"""从带时间戳的转录生成逐句字幕，并构建网页发布包"""
import re, os, json, shutil, subprocess, sys
from PIL import Image

WS = r"C:\Users\gog98\Documents\lingxi-claw\users\247656584\projects\11955814199197869\workspace\意义智能"
SRC = os.path.join(WS, "有声读物_意义智能解读")
PUB = os.path.join(WS, "意义智能有声读物_发布包")
TRANS = os.path.join(WS, "《意义智能》：给智能装上方向舵_transcript_66UBFm3n6hCNiekJgLgXSV.txt")

# ---------- 1. 解析转录为分句字幕 ----------
text = open(TRANS, encoding="utf-8").read()
blocks = re.findall(r"\[(\d+):(\d+)\.(\d+),(\d+):(\d+)\.(\d+)\]([^\[]*)", text)
cues = []
for m in blocks:
    s = int(m[0])*60 + int(m[1]) + int(m[2])/1000
    e = int(m[3])*60 + int(m[4]) + int(m[5])/1000
    seg = m[6].strip()
    # 按句号/问号/感叹号分句
    parts = re.split(r"(?<=[。？！])", seg)
    parts = [p for p in parts if p.strip()]
    # 再按逗号切分长句（目标 <45 字）
    fine = []
    for p in parts:
        if len(p) <= 45:
            fine.append(p)
        else:
            buf = ""
            for piece in re.split(r"(?<=[，；：])", p):
                if len(buf) + len(piece) > 42 and buf:
                    fine.append(buf); buf = piece
                else:
                    buf += piece
            if buf: fine.append(buf)
    total = sum(len(f) for f in fine) or 1
    t = s
    for f in fine:
        d = (e - s) * len(f) / total
        cues.append({"s": round(t, 2), "e": round(min(t + d, e), 2), "t": f.strip()})
        t += d
print("字幕条数:", len(cues))

# ---------- 2. WebVTT ----------
def ts(x):
    h = int(x // 3600); mm = int(x % 3600 // 60); ss = int(x % 60); ms = int(x % 1 * 1000)
    return f"{h:02d}:{mm:02d}:{ss:02d}.{ms:03d}"
vtt = "WEBVTT\n\n" + "\n\n".join(
    f"{i+1}\n{ts(c['s'])} --> {ts(c['e'])}\n{c['t']}" for i, c in enumerate(cues))
os.makedirs(PUB, exist_ok=True)
open(os.path.join(PUB, "subtitles.vtt"), "w", encoding="utf-8").write(vtt)
json.dump(cues, open(os.path.join(PUB, "subtitles.json"), "w", encoding="utf-8"), ensure_ascii=False)

# ---------- 3. 压缩图片到发布包 ----------
assets = os.path.join(PUB, "assets")
os.makedirs(assets, exist_ok=True)
for f in os.listdir(SRC):
    if f.endswith((".png", ".jpg")):
        img = Image.open(os.path.join(SRC, f)).convert("RGB")
        w, h = img.size
        if max(w, h) > 1400:
            r = 1400 / max(w, h)
            img = img.resize((int(w*r), int(h*r)), Image.LANCZOS)
        out = os.path.join(assets, os.path.splitext(f)[0] + ".jpg")
        img.save(out, "JPEG", quality=82, optimize=True)
shutil.copy(os.path.join(SRC, "audio.mp3"), os.path.join(assets, "audio.mp3"))
print("资源就绪:", len(os.listdir(assets)))

# ---------- 4. 生成发布版 HTML ----------
html = open(os.path.join(SRC, "意义智能有声读物.html"), encoding="utf-8").read()
html = re.sub(r'src="([^"/:]+\.(?:png|jpg))"', r'src="assets/\1.jpg"', html)
html = html.replace('src="assets/cover.jpg.jpg"', 'src="assets/cover.jpg"')
# 字幕 UI
ui = """<div id="subBar" style="margin-top:12px;min-height:56px;background:rgba(0,0,0,.45);
border:1px solid var(--line);border-radius:10px;padding:12px 18px;font-size:17px;line-height:1.7;
color:#fff;text-align:center;letter-spacing:.5px">播放后此处将同步显示字幕</div>"""
html = html.replace('<div class="chapters" id="chapters"></div>',
                    '<div class="chapters" id="chapters"></div>\n' + ui)
html = html.replace('<audio id="audio" src="audio.mp3"',
                    '<audio id="audio" src="assets/audio-web.mp3"')
html = html.replace('src="cover.jpg"', 'src="assets/cover.jpg"')
script = """
<script id="subData" type="application/json">__CUES__</script>
<script>
const CUES=JSON.parse(document.getElementById('subData').textContent);
const sub=document.getElementById('subBar');
audio.addEventListener('timeupdate',()=>{
  const t=audio.currentTime;
  const c=CUES.find(c=>t>=c.s&&t<c.e);
  sub.textContent=c?c.t:sub.textContent;
  sub.style.color=c?'#fff':'var(--dim)';
});
</script>
"""
html = html.replace("</body>", script.replace("__CUES__", json.dumps(cues, ensure_ascii=False)) + "</body>")
open(os.path.join(PUB, "index.html"), "w", encoding="utf-8").write(html)
bilingual = os.path.join(WS, "build_bilingual.py")
if os.path.isfile(bilingual):
    subprocess.run([sys.executable, bilingual], check=True)
else:
    finalizer = os.path.join(WS, "meaning-intelligence-publish", "scripts", "finalize_publish.py")
    subprocess.run([sys.executable, finalizer], check=True)
print("index.html 生成完成")
