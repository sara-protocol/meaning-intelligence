from __future__ import annotations

import hashlib
import io
import json
import re
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_COLOR_INDEX
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8", errors="backslashreplace")

WORKSPACE = Path(r"C:\Users\gog98\Documents\lingxi-claw\users\247656584\projects\11955814199197869\workspace\意义智能")
REPO = WORKSPACE / "mi-repo"
OUT = WORKSPACE / "deliverables" / "documents"
SOURCE = Path(r"C:\Users\gog98\Desktop\推广\意义智能\Meaningful Intelligence- Theoretical Fou.docx")
MANUAL_MD = WORKSPACE / "意义智能有声读物_发布指南与操作手册.md"
REPORT_MD = OUT / "意义智能_项目审查与优化报告_2026-11-26.md"
REPORT_DOCX = OUT / "意义智能_项目审查与优化报告_2026-11-26.docx"
MANUAL_DOCX = OUT / "意义智能_有声读物_发布指南与操作手册_v3.0.docx"
DATE = "2026-11-26"
FIXED_TIME = datetime(2026, 11, 26, 0, 0, 0, tzinfo=timezone.utc)
BLUE = "173A5E"
TEAL = "0E7490"
LIGHT = "EAF2F8"
GRAY = "5B6573"

CANON_SHA = "0fedff1ee5775bbc6812cea24f6024e36e54d43fac4776ba6f94c402ff4cb574"
ENGLISH_SHA = "b4225b6371d0ea013fe2ae4db9ac396537e2bf30f94cbda5a2c342e5f570396b"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def set_run_font(run, name: str = "Microsoft YaHei", size: float | None = None,
                 bold: bool | None = None, color: str | None = None) -> None:
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def configure_styles(doc: Document, a4: bool = True) -> None:
    if a4:
        for section in doc.sections:
            section.page_width = Cm(21.0)
            section.page_height = Cm(29.7)
            section.left_margin = Cm(2.2)
            section.right_margin = Cm(2.0)
            section.top_margin = Cm(2.0)
            section.bottom_margin = Cm(1.8)
            section.header_distance = Cm(0.85)
            section.footer_distance = Cm(0.85)
    normal = doc.styles["Normal"]
    normal.font.name = "Microsoft YaHei"
    normal._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.22
    normal.paragraph_format.widow_control = True
    normal.paragraph_format.keep_together = True
    for list_name in ("List Bullet", "List Number"):
        if list_name not in [style.name for style in doc.styles]:
            doc.styles.add_style(list_name, WD_STYLE_TYPE.PARAGRAPH).base_style = normal
        style = doc.styles[list_name]
        style.font.name = "Microsoft YaHei"
        style._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(10.5)
        style.paragraph_format.space_after = Pt(3)
        style.paragraph_format.line_spacing = 1.18
        style.paragraph_format.widow_control = True
    for level, size, color in ((1, 19, BLUE), (2, 14, BLUE), (3, 11.5, TEAL), (4, 10.5, TEAL)):
        style = doc.styles[f"Heading {level}"]
        style.font.name = "Microsoft YaHei"
        style._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(15 if level == 1 else 10)
        style.paragraph_format.space_after = Pt(6)
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.keep_together = True
        style.paragraph_format.widow_control = True
    if "Code Block" not in [style.name for style in doc.styles]:
        code = doc.styles.add_style("Code Block", WD_STYLE_TYPE.PARAGRAPH)
    else:
        code = doc.styles["Code Block"]
    code.font.name = "Consolas"
    code._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    code.font.size = Pt(8)
    code.paragraph_format.left_indent = Cm(0.35)
    code.paragraph_format.right_indent = Cm(0.2)
    code.paragraph_format.space_after = Pt(0)
    code.paragraph_format.line_spacing = 1.0
    code.paragraph_format.widow_control = True


def add_field(paragraph, instruction: str) -> None:
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    text = OxmlElement("w:instrText")
    text.set(qn("xml:space"), "preserve")
    text.text = instruction
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, text, separate, end])
    set_run_font(run, size=8, color=GRAY)


def add_header_footer(doc: Document, header_text: str,
                      footer_text: str = "意义智能 · V7.0 对齐版本") -> None:
    for section in doc.sections:
        section.different_first_page_header_footer = True
        for part in (section.header, section.footer, section.even_page_header,
                     section.even_page_footer, section.first_page_header,
                     section.first_page_footer):
            for paragraph in part.paragraphs:
                paragraph.text = ""
        doc.settings.odd_and_even_pages_header_footer = False
        header = section.header.paragraphs[0]
        header.text = header_text
        header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        header.paragraph_format.space_after = Pt(0)
        for run in header.runs:
            set_run_font(run, size=8, color=GRAY)
        p_pr = header._p.get_or_add_pPr()
        borders = OxmlElement("w:pBdr")
        bottom = OxmlElement("w:bottom")
        bottom.set(qn("w:val"), "single")
        bottom.set(qn("w:sz"), "4")
        bottom.set(qn("w:space"), "4")
        bottom.set(qn("w:color"), "C7D5E3")
        borders.append(bottom)
        p_pr.append(borders)
        footer = section.footer.paragraphs[0]
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer.paragraph_format.space_after = Pt(0)
        run = footer.add_run(footer_text + "　|　")
        set_run_font(run, size=8, color=GRAY)
        add_field(footer, "PAGE")
        run = footer.add_run(" / ")
        set_run_font(run, size=8, color=GRAY)
        add_field(footer, "NUMPAGES")
        for first in (section.first_page_header, section.first_page_footer):
            first.paragraphs[0].text = ""
    settings = doc.settings.element
    update = settings.find(qn("w:updateFields"))
    if update is None:
        update = OxmlElement("w:updateFields")
        settings.append(update)
    update.set(qn("w:val"), "true")


def shade_cell(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_text(cell, text: str, bold: bool = False, color: str | None = None,
                  size: float = 9) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_after = Pt(2)
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.line_spacing = 1.08
    paragraph.paragraph_format.widow_control = True
    run = paragraph.add_run(str(text))
    set_run_font(run, size=size, bold=bold, color=color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def add_table(doc: Document, headers: list[str], rows: list[list[str]],
              widths: list[float] | None = None, font_size: float = 9) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = OxmlElement(f"w:{edge}")
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:color"), "C7D5E3")
        borders.append(element)
    tbl_pr.append(borders)
    margins = OxmlElement("w:tblCellMar")
    for edge in ("top", "left", "bottom", "right"):
        element = OxmlElement(f"w:{edge}")
        element.set(qn("w:w"), "85")
        element.set(qn("w:type"), "dxa")
        margins.append(element)
    tbl_pr.append(margins)
    if widths:
        for index, width in enumerate(widths):
            table.columns[index].width = Cm(width)
    header = table.rows[0]
    prevent_row_split(header)
    tr_pr = header._tr.get_or_add_trPr()
    repeat = OxmlElement("w:tblHeader")
    repeat.set(qn("w:val"), "true")
    tr_pr.append(repeat)
    for index, text in enumerate(headers):
        set_cell_text(header.cells[index], text, bold=True, color="FFFFFF", size=font_size)
        shade_cell(header.cells[index], BLUE)
        if widths:
            header.cells[index].width = Cm(widths[index])
    for row_index, values in enumerate(rows):
        row = table.add_row()
        prevent_row_split(row)
        for index, value in enumerate(values):
            set_cell_text(row.cells[index], value, size=font_size)
            if widths:
                row.cells[index].width = Cm(widths[index])
            if row_index % 2 == 1:
                shade_cell(row.cells[index], "F4F7FA")
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(3)
    spacer.paragraph_format.line_spacing = Pt(1)
    spacer.add_run().font.size = Pt(1)


def add_bullets(doc: Document, items: list[str]) -> None:
    for item in items:
        paragraph = doc.add_paragraph()
        paragraph.paragraph_format.left_indent = Cm(0.55)
        paragraph.paragraph_format.first_line_indent = Cm(-0.35)
        paragraph.add_run("• " + item)


def add_numbered(doc: Document, items: list[str]) -> None:
    for index, item in enumerate(items, 1):
        paragraph = doc.add_paragraph()
        paragraph.paragraph_format.left_indent = Cm(0.65)
        paragraph.paragraph_format.first_line_indent = Cm(-0.45)
        paragraph.add_run(f"{index}. " + item)


def add_cover(doc: Document, title: str, subtitle: str, descriptor: str) -> None:
    doc.add_paragraph().paragraph_format.space_after = Pt(36)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(title)
    set_run_font(r, size=27, bold=True, color=BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(subtitle)
    set_run_font(r, size=16, bold=True, color=TEAL)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(descriptor)
    set_run_font(r, size=11, color=GRAY)
    doc.add_paragraph().paragraph_format.space_after = Pt(20)
    for line in (
        f"校订日期：{DATE}",
        "正典依据：《意义智能：意义文明的认知操作系统》V7.0",
        "项目版本：Research System v0.2.0 · White Paper v1.1",
        "项目主页：https://msi.gojj.ccwu.cc/",
        "有声读物与媒体中心：https://goii.ccwu.cc/",
        "源码仓库：https://github.com/sara-protocol/meaning-intelligence",
    ):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(line)
        set_run_font(r, size=10, color=GRAY)
    doc.add_paragraph().paragraph_format.space_after = Pt(24)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("版本声明")
    set_run_font(r, size=11, bold=True, color=BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("本文件是项目衍生文档，不替代、不改写、不重新编号 V7.0 正典。所有正典原件保持只读。")
    set_run_font(r, size=9.5, color=GRAY)
    doc.add_page_break()


def add_final_cover(doc: Document, title: str, subtitle: str,
                    metadata: list[str], notice: str) -> None:
    doc.add_paragraph().paragraph_format.space_after = Pt(42)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(12)
    r = p.add_run(title)
    set_run_font(r, size=26, bold=True, color=BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(24)
    r = p.add_run(subtitle)
    set_run_font(r, size=14, bold=True, color=TEAL)
    p_pr = p._p.get_or_add_pPr()
    borders = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "12")
    bottom.set(qn("w:space"), "12")
    bottom.set(qn("w:color"), TEAL)
    borders.append(bottom)
    p_pr.append(borders)
    for line in metadata:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(5)
        r = p.add_run(line)
        set_run_font(r, size=9.5, color=GRAY)
    doc.add_paragraph().paragraph_format.space_after = Pt(24)
    add_note(doc, "文档声明", notice)
    doc.add_page_break()


def save_deterministic(doc: Document, path: Path) -> None:
    """Save a DOCX with stable ZIP member timestamps for repeatable hashes."""
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    output = io.BytesIO()
    with zipfile.ZipFile(buffer, "r") as source, zipfile.ZipFile(output, "w") as target:
        for info in source.infolist():
            info.date_time = (2026, 11, 26, 0, 0, 0)
            target.writestr(info, source.read(info.filename))
    path.write_bytes(output.getvalue())


def add_note(doc: Document, label: str, text: str) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.35)
    p.paragraph_format.right_indent = Cm(0.35)
    p.paragraph_format.space_before = Pt(5)
    p.paragraph_format.space_after = Pt(8)
    r = p.add_run(f"【{label}】")
    set_run_font(r, size=9.5, bold=True, color=TEAL)
    r = p.add_run(text)
    set_run_font(r, size=9.5, color=GRAY)
    p_pr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), LIGHT)
    p_pr.append(shd)


def add_evidence_table(doc: Document) -> None:
    doc.add_heading("E0–E6：V7.0 现行判据", level=2)
    add_table(doc, ["等级", "V7.0 含义", "不能误读为"], [
        ["E0", "理论构念已定义 / Construct defined", "已经得到实证支持"],
        ["E1", "已建立数学模型 / Mathematical model established", "模型已被现实数据验证"],
        ["E2", "已有测量工具，信效度验证中 / Instrument exists; validation under way", "量表已成熟或跨文化适用"],
        ["E3", "有预注册假设，数据收集中 / Preregistered hypothesis; data collection under way", "已经做出成功预测"],
        ["E4", "独立实验室复现结果 / Independent-laboratory replication", "同实验室重复或外部文献引用"],
        ["E5", "预注册证伪标准已检验 / Preregistered falsification criterion tested", "主张必然正确；E5 同时包含证伪出口"],
        ["E6", "跨情境、跨文化、跨时间泛化 / Generalization across contexts, cultures, and time", "单一外部领域提及或单次验证"],
    ], widths=[1.3, 9.0, 6.3])
    add_note(doc, "判据边界", "证据等级描述知识状态，不是质量评分，也不是进度条。未版本化地升级 E3/E6 会造成证据等级虚高。")


def add_layer_table(doc: Document) -> None:
    doc.add_heading("六层工程栈：本框架操作化与正典关联分开标注", level=2)
    add_table(doc, ["层", "本框架状态", "正典关联", "边界"], [
        ["L1 减负", "本框架 E1；机制待核验", "无直接 H 映射", "工程草案，不得借用外部机制等级"],
        ["L2 可体验", "本框架 E1；机制待核验", "无直接 H 映射", "工程草案，不得借用外部机制等级"],
        ["L3 意义生成", "本框架 E0–E1；机制 E0", "H2；§3.2；§8.1", "正典三层次已重释为连续光谱带"],
        ["L4 价值评估", "本框架 E2（工具）/ E1（模型）", "H10", "H10 检验量表信度，不等于工程层有效"],
        ["L5 方向选择", "本框架 E1", "H7 / H8", "关联不等同；工程选路优势需单独检验"],
        ["L6 反思与审视递归", "本框架 E2", "H12 / H13（E2）；H14（E1）", "归零、元认知、无归零僵化不得共用一个失败结论"],
        ["六层栈本身", "E0", "非正典固定结构", "可被更简洁且解释力更强的切分替换"],
    ], widths=[2.7, 4.0, 3.8, 6.1], font_size=8.5)
    add_note(doc, "来源声明", "L1–L6 与界面带／加工带／元带是本项目 E0 工程扩展。正典 H1–H18 与附录 D.7 的五模块失败矩阵独立有效，不由工程表替代。")


def add_upstream_table(doc: Document) -> None:
    doc.add_heading("正典原件待修问题与本次处置", level=2)
    add_table(doc, ["问题", "正典事实", "衍生文档处置"], [
        ["H5 等级截断", "附录 D.2 写为 r；H5 卡片为 r > 0.7 / r < −0.7；E0", "引用信息更完整的 H5 卡片；保留冲突记录"],
        ["H6 简表与卡片冲突", "简表写“极慢速率有危机”；卡片写“极慢但意义状态健康”", "采用卡片并留痕；不静默修补正典"],
        ["双语不完整", "正文主体为中文，英文主要在标题与图注", "不称为完整双语正文；英文内容按衍生材料标注"],
        ["图片与附录占位", "四份候选 DOCX 均无内嵌图片；38 图、4 份实验协议、术语表存在占位", "记录为上游缺口；发布插图不得冒充正典原图"],
        ["重复副本", "定稿02 与 V5 同 SHA-256", "明确归档关系，避免并行修改分叉"],
    ], widths=[3.1, 7.0, 6.5], font_size=8.5)


def add_artifact_status(doc: Document) -> None:
    doc.add_heading("2026 工程与发布成果", level=2)
    add_table(doc, ["交付物", "已核验事实", "状态口径"], [
        ["白皮书 v1.1", "DOCX 310 段、9 表、3 图；PDF 22 页", "元数据与实际产物一致"],
        ["MSI 演示 v2.1", "8 幕，配置约 43 秒；过载 45 条 → 核心语句 3 条 → 结构节点 2 个；L3 示意 9 点", "计数按实现，不再使用 120/12 旧描述"],
        ["中英发布视频", "两版均 164.010667 秒、1920×1080、H.264/AAC；字幕、完整解码、音量与静音段检查通过", "已核验；不代表已部署"],
        ["意义智能智能体", "L1–L6 六技能注册；离线模式；默认人工批准 pending", "127/127 单元测试及本地浏览器边界检查通过"],
        ["公共 Web MCP", "只读资源与确定性分析；Bearer、Origin、体积、速率限制；Pages onRequest 适配器", "24/24 聚焦测试通过；Function 已编译上传；生产认证调用未进行"],
        ["电子书与下载", "中英 EPUB、音频、字幕、白皮书、PPT、源码 ZIP", "以最终 manifest 的路径、字节数与 SHA-256 为准"],
        ["双语项目说明书", "18 章中英图文、音频与字幕；离线入口与双语切换", "127/127 结构与 68/68 浏览器检查通过"],
        ["项目主页", "https://msi.gojj.ccwu.cc/", "GitHub Pages 项目主页；与媒体中心不混用"],
        ["视听中心", "https://goii.ccwu.cc/", "既有公开地址仍为旧版；最终发布待公网放行"],
    ], widths=[3.2, 8.0, 5.4], font_size=8.5)


def build_attachment_update() -> Path:
    before = sha256(SOURCE)
    doc = Document(SOURCE)
    configure_styles(doc, a4=False)
    add_header_footer(doc, "意义智能 · 附件衍生更新版")
    first = doc.paragraphs[0]
    cover_lines = [
        ("意义智能：理论基础、实现框架与多尺度应用", "Normal", 25, BLUE, True),
        ("附件衍生更新版", "Normal", 18, TEAL, True),
        ("V7.0 对齐 · 正典审计 · 工程边界 · 2026 发布成果补充", "Normal", 12, GRAY, False),
        (f"校订日期：{DATE}", "Normal", 10, GRAY, False),
        ("本文件由用户附件复制生成；原附件未修改。", "Normal", 10, GRAY, False),
        ("V7.0 正典原件保持只读，本更新版不替代正典。", "Normal", 10, GRAY, False),
        ("项目主页：https://msi.gojj.ccwu.cc/", "Normal", 10, GRAY, False),
        ("有声读物与媒体中心：https://goii.ccwu.cc/", "Normal", 10, GRAY, False),
        ("源码仓库：https://github.com/sara-protocol/meaning-intelligence", "Normal", 10, GRAY, False),
    ]
    for text, style_name, size, color, bold in cover_lines:
        p = first.insert_paragraph_before(style=style_name)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(text)
        set_run_font(r, size=size, bold=bold, color=color)
    p = first.insert_paragraph_before(style="Heading 1")
    p.add_run("原附件正文（保留主体）")
    p.add_run().add_break(WD_BREAK.PAGE)

    notes = {
        8: "本段列举的外部研究用于说明问题背景。本次项目审计未完成全部外部文献的预注册、复现与泛化条件核验，因此不得把这些文献直接当作 V7.0 正典或六层工程栈的高等级证据。",
        26: "本段“四层工程实现”属于应用架构描述，不是 V7.0 正典规定的固定四层。项目现行 L1–L6 六层栈与三带是 E0 工程扩展，须与正典 H1–H18、附录 D.7 分开引用。",
        33: "10%／30% 分级修正是附件原有的操作化表述。它不是本次审计核验过的正典预注册阈值；用于实验前必须登记样本量、统计方案、最小可判别效应与处置规则。",
    }
    for index, text in notes.items():
        p = doc.paragraphs[index + len(cover_lines) + 1]
        r = p.add_run(f"　【2026 校订注】{text}")
        set_run_font(r, size=9, color=TEAL)
        r.font.highlight_color = WD_COLOR_INDEX.YELLOW

    doc.add_page_break()
    doc.add_heading("附录 A　V7.0 证据等级与本次对齐", level=1)
    doc.add_paragraph("本附录优先采用 V7.0 正典表 I.2 的定义。项目早期文档中把 E3 写成“在新数据上预测正确”、把 E6 写成“框架外领域独立确认”的表述已废止。")
    add_evidence_table(doc)

    doc.add_heading("附录 B　正典来源、权威顺序与上游待修问题", level=1)
    doc.add_paragraph("权威顺序：KDP 定稿02中文 V7 正典 → Meaning IntelligenceV7 英文母本 → whitepaper 应用层白皮书 → msi/config.json 工程实现 → README／CHANGELOG 等传播材料。版本号只认 VERSION.yaml；场景实现以 config.json、场景代码与实测时间轴为准。")
    add_table(doc, ["来源", "SHA-256", "判定"], [
        ["定稿02／意义智能_V7升级版_KDP中英双语.docx", CANON_SHA, "主正典"],
        ["V5／同名 DOCX", CANON_SHA, "同哈希归档副本，不独立维护"],
        ["Meaning IntelligenceV7.docx", ENGLISH_SHA, "英文校对母本"],
        ["定稿01／旧英文版", "不同代版本", "排除；无 V7.0/E0–E6，仅旧 P1–P18"],
    ], widths=[6.0, 7.0, 3.6], font_size=8)
    add_upstream_table(doc)

    doc.add_heading("附录 C　六层工程栈与失败矩阵的边界", level=1)
    add_layer_table(doc)
    doc.add_paragraph("正典附录 D.7 的五模块失败矩阵是 SG、Spectrum Spiral、Witness→Leap、MI-AI、Weaving Sovereignty。仓库旧“六层失败矩阵”不是正典矩阵；现行文档拆成“正典五模块／H1–H18／工程草案”三层。")
    add_bullets(doc, [
        "正典假设按正典处置，工程草案不得覆盖 H1–H18 或附录 D.7。",
        "未预注册的工程条件只能指导探索，不能触发正式“标记或删除”。",
        "一次失败只推翻被检验的主张；工程层失败不自动推翻外部机制。",
        "处置必须在 CHANGELOG 留痕，写明对象、版本、证据与理由。",
    ])

    doc.add_heading("附录 D　项目实现与发布成果", level=1)
    add_artifact_status(doc)
    doc.add_paragraph("下载中心与最终完整交付包以发布页 manifest 为准：每个文件记录相对路径、字节数、媒体格式与 SHA-256。网站资源、电子书、音频、字幕、视频、白皮书、PPT、智能体源码、Web MCP 与 Word 文档集中打包。")

    doc.add_heading("附录 E　本附件更新记录", level=1)
    add_table(doc, ["位置", "更新类型", "说明"], [
        ["封面", "新增", "明确衍生更新版身份、日期、正典只读与两个网站的不同用途"],
        ["原正文外部研究段", "校订注", "外部机制文献与项目证据链分开，避免证据等级转移"],
        ["原正文工程实现段", "校订注", "四层架构描述与六层工程扩展区分"],
        ["原正文递归校准段", "校订注", "10%／30% 阈值标为待预注册操作化草案"],
        ["附录 A–D", "新增", "证据定义、来源审计、工程边界、实现与发布成果"],
        ["参考文献", "补充", "新增 V7 正典、英文母本、仓库、白皮书、审计与网站入口"],
    ], widths=[4.0, 2.6, 10.0], font_size=8.5)

    doc.add_heading("新增参考文献", level=2)
    references = [
        "[11] 《意义智能：意义文明的认知操作系统》V7.0，KDP 定稿02主正典；SHA-256 " + CANON_SHA,
        "[12] Meaning IntelligenceV7.docx，英文校对母本；SHA-256 " + ENGLISH_SHA,
        "[13] Meaning Intelligence 项目仓库：https://github.com/sara-protocol/meaning-intelligence",
        "[14] 《意义智能 · 元智能理论与分层应用》公开白皮书 v1.1（22 页／9 表／3 图）",
        "[15] 正典审计：https://github.com/sara-protocol/meaning-intelligence/blob/main/docs/canon-audit.md",
        "[16] 项目主页：https://msi.gojj.ccwu.cc/",
        "[17] 双语有声读物与媒体中心：https://goii.ccwu.cc/",
    ]
    for item in references:
        doc.add_paragraph(item)
    add_note(doc, "原参考文献", "原附件 [1]–[10] 保留以便追溯；其中 [2]、[5] 为 opaque 文档链接，[1] 文件名缺少版本与哈希。正式引用理论时请优先使用 [11]–[15]。")

    props = doc.core_properties
    props.title = "意义智能：理论基础、实现框架与多尺度应用（附件衍生更新版）"
    props.subject = "V7.0 对齐、正典审计与 2026 工程成果补充"
    props.author = "Meaning Intelligence Project"
    props.last_modified_by = "Meaning Intelligence Project"
    props.comments = "Derivative update; original attachment and V7.0 canon remain unchanged."
    props.modified = FIXED_TIME
    out = OUT / "意义智能_附件衍生更新版_2026-11-26.docx"
    save_deterministic(doc, out)
    if sha256(SOURCE) != before:
        raise RuntimeError("Source attachment changed unexpectedly")
    return out


def build_supplement() -> Path:
    doc = Document()
    configure_styles(doc)
    add_header_footer(doc, "意义智能 · 书稿勘误与补充说明")
    add_cover(doc, "意义智能书稿勘误与补充说明", "V7.0 正典只读 · 衍生版本可校订", "供作者、编辑、研究系统维护者与发布人员使用")
    doc.add_heading("使用说明", level=1)
    doc.add_paragraph("本说明回答三个问题：哪些内容属于正典、哪些内容属于项目工程扩展、本次书稿更新具体改了什么。它不修改 KDP 正典原件，也不把工程演示当作实证结论。")
    add_numbered(doc, [
        "正式理论引用以 V7.0 主正典为准，英文术语以 Meaning IntelligenceV7 英文母本为准。",
        "项目实现、六层栈、白皮书与网页内容属于应用层，必须标注工程身份和证据状态。",
        "任何证据等级、计数、版本或媒体规格变更，都应同步更新 VERSION.yaml、生成脚本、产物和验收清单。",
    ])

    doc.add_heading("一、来源判定与权威顺序", level=1)
    add_table(doc, ["候选", "判定", "证据"], [
        ["定稿02 V7 KDP 中英双语 DOCX", "主正典", "含 V7.0、25 章、H1–H18、附录 A–H、E0–E6"],
        ["V5 同名副本", "同哈希归档", "与定稿02 SHA-256 相同，不独立维护"],
        ["Meaning IntelligenceV7.docx", "英文校对母本", "同代完整英文文本，用于标题与术语核对"],
        ["定稿01旧英文版", "排除", "标题为 The Positioning of Meaning Intelligence；无 V7.0/E0–E6"],
    ], widths=[5.2, 3.2, 8.2])
    doc.add_paragraph("主正典 SHA-256：" + CANON_SHA)
    doc.add_paragraph("英文母本 SHA-256：" + ENGLISH_SHA)

    doc.add_heading("二、上游待修问题", level=1)
    add_upstream_table(doc)
    add_note(doc, "不静默补写", "H5、H6、缺失插图、术语占位与双语不完整均记录为上游修订建议。衍生版本可以说明和补充，但不能伪装成已经修复的正典原件。")

    doc.add_heading("三、V7.0 证据判据", level=1)
    add_evidence_table(doc)
    doc.add_paragraph("项目当前不主张六层栈、智能体或 Web MCP 已获得独立实证验证。软件可运行、页面可访问、测试通过，只证明工程行为符合规格，不证明理论主张为真。")

    doc.add_heading("四、六层工程栈与正典假设映射", level=1)
    add_layer_table(doc)
    doc.add_paragraph("六层栈本身仍是 E0。把它数据化、动画化、接入智能体，改变的是可体验程度，不是证据等级。若出现更简洁且解释力更强的切分，应替换而不是辩护。")

    doc.add_heading("五、失败矩阵与预注册门槛", level=1)
    doc.add_paragraph("正典附录 D.7 的五模块失败矩阵与 H1–H18 假设卡片独立于工程层。工程草案转为正式阈值前，至少需要：")
    add_numbered(doc, [
        "在观察数据前登记假设、样本量、统计检验、最小可判别效应与处置规则。",
        "明确被检验组件，避免把递归审视、主动归零、元认知与无归零僵化混为一个对象。",
        "保存带时间戳和版本的登记记录，并允许第三方复核。",
        "失败只推翻被检验主张；结果无论正负都公开，不以叙事补救替代处置。",
    ])

    doc.add_heading("六、附件正文的具体补充", level=1)
    add_table(doc, ["附件位置", "补充内容", "理由"], [
        ["封面与版本说明", "衍生更新版身份、日期、来源哈希、两个网站的不同用途", "避免与 V7.0 正典或项目主页混淆"],
        ["外部研究段", "外部机制文献不等于项目证据链", "防止把文献成熟度转移给六层操作化"],
        ["工程实现段", "四层应用架构与六层工程扩展分开", "防止把工程切分写成正典结构"],
        ["递归校准段", "10%／30% 阈值需预注册", "防止草案阈值被当作已确立标准"],
        ["新增附录", "E0–E6、H5/H6、六层边界、MSI 计数、发布成果", "用一处集中附录降低正文重复维护"],
        ["新增参考文献", "正典、英文母本、仓库、白皮书、审计与网站", "替换含糊的版本与链接引用"],
    ], widths=[3.6, 7.0, 6.0], font_size=8.5)

    doc.add_heading("七、项目计数与版本事实", level=1)
    add_artifact_status(doc)
    doc.add_paragraph("版本号唯一真相源是 VERSION.yaml：正典 V7.0；研究系统 v0.2.0；操作栈 v2.0／E0；白皮书 v1.1；MSI 演示 v2.1。工程版本不静默改写正典证据定义或 H1–H18 阈值。")

    doc.add_heading("八、书稿与发布内容的一致性规则", level=1)
    add_bullets(doc, [
        "理论章节引用 V7.0；工程章节引用仓库版本与配置；传播材料引用公开白皮书。",
        "所有数字必须能从配置、生成脚本或媒体探测中复现；无法复现的数字删除或标注待核验。",
        "中文与英文页面必须同步切换标题、正文、图注、字幕、音频与下载说明，不得只切标题。",
        "插图必须标明“项目示意图”或“正典原图”；不得用发布插图冒充缺失的正典图。",
        "网站下载清单必须记录路径、字节数和 SHA-256；完整 ZIP 必须再次验证成员完整性。",
        "任何“已部署”“已测试”“已复现”的表述都必须有命令输出、浏览器观察或独立探测证据。",
    ])

    doc.add_heading("九、交付与验收状态口径", level=1)
    add_table(doc, ["状态", "含义", "允许表述"], [
        ["已实现", "文件或代码存在", "“已实现”，不得写成“已部署”或“已验证”"],
        ["已测试", "明确测试命令通过", "写明测试范围、数量和环境"],
        ["已部署", "生产地址返回预期内容", "写明 URL、时间与探测结果"],
        ["已实证", "满足 V7.0 对应证据判据", "必须给出预注册、数据、统计与独立性证据"],
        ["待核验", "缺少项目内可复核证据", "明确缺口，不借用邻近对象等级"],
    ], widths=[2.6, 6.2, 7.8], font_size=8.5)

    doc.add_heading("十、参考入口", level=1)
    for item in (
        "项目仓库：https://github.com/sara-protocol/meaning-intelligence",
        "项目主页：https://msi.gojj.ccwu.cc/",
        "双语有声读物与媒体中心：https://goii.ccwu.cc/",
        "正典审计：docs/canon-audit.md",
        "证据体系：docs/evidence.md",
        "失败矩阵：docs/failure-matrix.md",
        "术语对照：docs/glossary.md",
    ):
        doc.add_paragraph(item)
    props = doc.core_properties
    props.title = "意义智能书稿勘误与补充说明"
    props.subject = "V7.0 provenance, evidence definitions, manuscript errata and engineering boundaries"
    props.author = "Meaning Intelligence Project"
    props.last_modified_by = "Meaning Intelligence Project"
    props.modified = FIXED_TIME
    out = OUT / "意义智能_书稿勘误与补充说明_2026-11-26.docx"
    save_deterministic(doc, out)
    return out


def clean_inline(text: str) -> str:
    text = re.sub(r"!\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1（\2）", text)
    text = text.replace("**", "").replace("__", "").replace("`", "")
    return text


def add_inline_text(paragraph, text: str, size: float | None = None) -> None:
    token = re.compile(r"(\*\*.+?\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\))")
    for part in token.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            set_run_font(run, size=size, bold=True, color=BLUE)
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            set_run_font(run, name="Consolas", size=(size or 9.5) - 0.5, color=TEAL)
        else:
            link = re.fullmatch(r"\[([^\]]+)\]\(([^)]+)\)", part)
            if link:
                run = paragraph.add_run(link.group(1))
                set_run_font(run, size=size, color=TEAL)
                run = paragraph.add_run("（" + link.group(2) + "）")
                set_run_font(run, size=(size or 10.5) - 1, color=GRAY)
            else:
                run = paragraph.add_run(part)
                if size is not None:
                    set_run_font(run, size=size)


def table_widths(headers: list[str]) -> list[float] | None:
    if headers == ["来源", "角色", "SHA-256 / 判定"]:
        return [5.0, 3.1, 8.7]
    if headers == ["等级", "V7.0 判据"]:
        return [2.0, 14.8]
    if headers == ["缺陷", "当前处置"]:
        return [7.0, 9.8]
    if headers == ["交付物", "当前证据", "状态"]:
        return [3.7, 8.6, 4.5]
    return None


def add_markdown_table(doc: Document, lines: list[str]) -> None:
    rows = []
    for line in lines:
        values = [clean_inline(value.strip()) for value in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r":?-{3,}:?", value) for value in values):
            continue
        rows.append(values)
    if not rows:
        return
    headers = rows[0]
    widths = table_widths(headers) or [16.8 / len(headers)] * len(headers)
    add_table(doc, headers, rows[1:], widths=widths, font_size=8.5)


def extract_front_matter(lines: list[str]) -> tuple[str, list[str], int]:
    title_index = next(index for index, line in enumerate(lines) if re.match(r"^#\s+", line.strip()))
    title = clean_inline(re.sub(r"^#\s+", "", lines[title_index].strip()))
    metadata: list[str] = []
    index = title_index + 1
    while index < len(lines):
        text = lines[index].strip()
        if not text:
            index += 1
            continue
        if text in ("---", "***", "___"):
            return title, metadata, index + 1
        if text.startswith(">"):
            metadata.append(clean_inline(text.lstrip("> ")))
            index += 1
            continue
        if re.match(r"^\*\*[^*]+：\*\*", text):
            metadata.append(clean_inline(text))
            index += 1
            continue
        break
    return title, metadata, index


def style_heading(paragraph, level: int) -> None:
    if level == 1:
        p_pr = paragraph._p.get_or_add_pPr()
        borders = OxmlElement("w:pBdr")
        bottom = OxmlElement("w:bottom")
        bottom.set(qn("w:val"), "single")
        bottom.set(qn("w:sz"), "6")
        bottom.set(qn("w:space"), "5")
        bottom.set(qn("w:color"), "C7D5E3")
        borders.append(bottom)
        p_pr.append(borders)


def markdown_to_docx(md_path: Path, out_path: Path, title: str) -> Path:
    doc = Document()
    configure_styles(doc)
    is_report = out_path == REPORT_DOCX
    footer = "意义智能 · 项目审查报告 v1.1" if is_report else "意义智能 · 发布指南与操作手册 v3.0"
    add_header_footer(doc, title, footer)
    lines = md_path.read_text(encoding="utf-8").splitlines()
    cover_title, metadata, index = extract_front_matter(lines)
    if is_report:
        subtitle = "v1.1 · 本地交付已核验 · 公网发布受阻"
        notice = "本报告区分本地已核验、发布受阻与上游待修。自动化测试不代表理论已获实证支持；Function 已上传也不代表生产地址可公网访问或完成验收。"
        new_page_prefixes = ()
    else:
        subtitle = "v3.0 · 本地构建、验收与授权发布"
        notice = "本手册中的部署命令是获授权后的操作流程，不表示部署已经发生。正典、原始书稿、项目说明书、发布脚本与打包器均不因本手册生成而修改。"
        new_page_prefixes = ("五、Cloudflare Pages 部署", "六、内容更新")
    add_final_cover(doc, cover_title, subtitle, metadata, notice)
    while index < len(lines):
        raw = lines[index]
        text = raw.strip()
        if not text:
            index += 1
            continue
        if text.startswith("```"):
            index += 1
            block = []
            while index < len(lines) and not lines[index].strip().startswith("```"):
                block.append(lines[index])
                index += 1
            for block_index, line in enumerate(block):
                paragraph = doc.add_paragraph(line, style="Code Block")
                paragraph.paragraph_format.keep_together = True
                paragraph.paragraph_format.keep_with_next = True
                paragraph.paragraph_format.space_before = Pt(4 if block_index == 0 else 0)
                paragraph.paragraph_format.space_after = Pt(8 if block_index == len(block) - 1 else 0)
                p_pr = paragraph._p.get_or_add_pPr()
                shd = OxmlElement("w:shd")
                shd.set(qn("w:fill"), "F4F7FA")
                p_pr.append(shd)
            index += 1
            continue
        if text.startswith("|") and index + 1 < len(lines) and re.match(r"^\|?\s*:?-{3,}", lines[index + 1].strip()):
            table_lines = [text]
            index += 1
            while index < len(lines) and lines[index].strip().startswith("|"):
                table_lines.append(lines[index])
                index += 1
            add_markdown_table(doc, table_lines)
            continue
        if text in ("---", "***", "___"):
            index += 1
            continue
        match = re.match(r"^(#{1,6})\s+(.*)$", text)
        if match:
            level = max(1, min(4, len(match.group(1)) - 1))
            heading = clean_inline(match.group(2))
            paragraph = doc.add_heading(heading, level=level)
            style_heading(paragraph, level)
            if level == 1 and heading.startswith(new_page_prefixes):
                paragraph.paragraph_format.page_break_before = True
            index += 1
            continue
        if text.startswith(">"):
            quote = clean_inline(text.lstrip("> "))
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.left_indent = Cm(0.6)
            paragraph.paragraph_format.keep_together = True
            run = paragraph.add_run(quote)
            set_run_font(run, size=9.5, color=GRAY)
            index += 1
            continue
        bullet = re.match(r"^[-*+]\s+", text)
        if bullet:
            item = re.sub(r"^[-*+]\s+", "", text)
            nesting = max(0, (len(raw) - len(raw.lstrip())) // 2)
            paragraph = doc.add_paragraph(style="List Bullet")
            paragraph.paragraph_format.left_indent = Cm(0.65 + nesting * 0.45)
            paragraph.paragraph_format.first_line_indent = Cm(-0.35)
            paragraph.paragraph_format.keep_together = True
            if item.startswith("[ ] "):
                paragraph.style = doc.styles["Normal"]
                paragraph.paragraph_format.left_indent = Cm(0.65 + nesting * 0.45)
                paragraph.paragraph_format.first_line_indent = Cm(-0.45)
                add_inline_text(paragraph, "☐ " + item[4:])
            elif item.startswith("[x] "):
                paragraph.style = doc.styles["Normal"]
                paragraph.paragraph_format.left_indent = Cm(0.65 + nesting * 0.45)
                paragraph.paragraph_format.first_line_indent = Cm(-0.45)
                add_inline_text(paragraph, "☑ " + item[4:])
            else:
                add_inline_text(paragraph, item)
            index += 1
            continue
        numbered = re.match(r"^(\d+)[.)]\s+(.*)$", text)
        if numbered:
            nesting = max(0, (len(raw) - len(raw.lstrip())) // 2)
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.left_indent = Cm(0.7 + nesting * 0.45)
            paragraph.paragraph_format.first_line_indent = Cm(-0.5)
            paragraph.paragraph_format.keep_together = True
            paragraph.paragraph_format.keep_with_next = (
                text.endswith(("：", ":")) or
                (index + 1 < len(lines) and lines[index + 1].strip().startswith("```"))
            )
            add_inline_text(paragraph, numbered.group(1) + ". " + numbered.group(2))
            index += 1
            continue
        paragraph = doc.add_paragraph()
        paragraph.paragraph_format.keep_together = True
        add_inline_text(paragraph, text)
        index += 1
    props = doc.core_properties
    props.title = title
    props.subject = "Generated reproducibly from Markdown with python-docx"
    props.author = "Meaning Intelligence Project"
    props.last_modified_by = "Meaning Intelligence Project"
    props.keywords = "意义智能,V7.0,工程边界,发布验收"
    props.created = FIXED_TIME
    props.modified = FIXED_TIME
    save_deterministic(doc, out_path)
    return out_path


def inspect_docx(path: Path, required: list[str], strict: bool = True) -> dict:
    with zipfile.ZipFile(path) as archive:
        bad_member = archive.testzip()
        if bad_member:
            raise RuntimeError(f"{path.name}: corrupt ZIP member {bad_member}")
        names = set(archive.namelist())
        for member in ("[Content_Types].xml", "word/document.xml", "word/styles.xml", "word/settings.xml"):
            if member not in names:
                raise RuntimeError(f"{path.name}: missing {member}")
    doc = Document(path)
    text = "\n".join(paragraph.text for paragraph in doc.paragraphs)
    text += "\n" + "\n".join(cell.text for table in doc.tables for row in table.rows for cell in row.cells)
    missing = [phrase for phrase in required if phrase not in text]
    if missing:
        raise RuntimeError(f"{path.name} missing required content: {missing}")
    levels = []
    for paragraph in doc.paragraphs:
        match = re.fullmatch(r"Heading ([1-4])", paragraph.style.name)
        if match:
            level = int(match.group(1))
            if strict and levels and level > levels[-1] + 1:
                raise RuntimeError(f"{path.name}: heading hierarchy skips from {levels[-1]} to {level}")
            if strict and not (paragraph.paragraph_format.keep_with_next or paragraph.style.paragraph_format.keep_with_next):
                raise RuntimeError(f"{path.name}: heading is not kept with next paragraph: {paragraph.text}")
            levels.append(level)
    if strict and (not levels or levels[0] != 1):
        raise RuntimeError(f"{path.name}: missing level-1 body heading")
    for table in doc.tables:
        for row_index, row in enumerate(table.rows):
            if strict and row._tr.get_or_add_trPr().find(qn("w:cantSplit")) is None:
                raise RuntimeError(f"{path.name}: table row {row_index} may split across pages")
        if strict and table.rows[0]._tr.get_or_add_trPr().find(qn("w:tblHeader")) is None:
            raise RuntimeError(f"{path.name}: table header is not repeated")
    return {
        "file": path.name,
        "format": "docx",
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
        "paragraphs": len(doc.paragraphs),
        "tables": len(doc.tables),
        "inline_shapes": len(doc.inline_shapes),
        "headings": len(levels),
        "strict_checks_applied": strict,
        "checks": {
            "zip_integrity": True,
            "required_content": True,
            "heading_hierarchy": True if strict else None,
            "heading_keep_with_next": True if strict else None,
            "table_rows_no_split": True if strict else None,
            "table_header_repeat": True if strict else None,
        },
    }


def inspect_pdf(path: Path, strict: bool = True) -> dict:
    import pymupdf

    pdf = pymupdf.open(path)
    blank_pages = []
    overflow_blocks = []
    missing_page_numbers = []
    for page_index, page in enumerate(pdf):
        text = page.get_text().strip()
        if len(text) < 5 and not page.get_images() and not page.get_drawings():
            blank_pages.append(page_index + 1)
        if strict and (abs(page.rect.width - 595.28) > 2 or abs(page.rect.height - 841.89) > 2):
            raise RuntimeError(f"{path.name}: page {page_index + 1} is not A4")
        for block in page.get_text("blocks"):
            x0, y0, x1, y1 = block[:4]
            if x0 < -1 or y0 < -1 or x1 > page.rect.width + 1 or y1 > page.rect.height + 1:
                overflow_blocks.append({"page": page_index + 1, "bounds": [x0, y0, x1, y1]})
        if page_index > 0 and not re.search(r"\b\d+\s*/\s*\d+\b", text):
            missing_page_numbers.append(page_index + 1)
    if blank_pages:
        raise RuntimeError(f"{path.name}: blank pages {blank_pages}")
    if overflow_blocks:
        raise RuntimeError(f"{path.name}: text blocks outside page bounds: {overflow_blocks}")
    if missing_page_numbers:
        raise RuntimeError(f"{path.name}: pages without page numbers: {missing_page_numbers}")
    record = {
        "file": path.name,
        "format": "pdf",
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
        "pages": pdf.page_count,
        "bookmarks": len(pdf.get_toc()),
        "strict_checks_applied": strict,
        "checks": {
            "a4_pages": True if strict else None,
            "no_blank_pages": True,
            "text_within_page_bounds": True,
            "page_numbers_present": True,
        },
    }
    pdf.close()
    return record


def build_manifest() -> dict:
    report = markdown_to_docx(REPORT_MD, REPORT_DOCX, "意义智能项目审查与优化报告")
    manual = markdown_to_docx(MANUAL_MD, MANUAL_DOCX, "意义智能有声读物发布指南与操作手册")
    required = {
        REPORT_DOCX: [
            "本地已核验", "发布受阻", "164.010667", "127/127",
            "24/24", "e3a56bea7362251d802c51a0d9c7a0f7ad26737f",
            "https://msi-axm.pages.dev", "final-verification.json",
            "Cloudflare Access", "未执行生产认证调用", "verify_package.py",
        ],
        MANUAL_DOCX: [
            "发布指南", "Cloudflare Pages", "verify_package.py", "goii.ccwu.cc",
            "MI_MCP_PUBLIC_TOKEN", "approval.status=pending",
        ],
    }
    final_docx = [REPORT_DOCX, MANUAL_DOCX]
    supporting_docx = [
        OUT / "意义智能_附件衍生更新版_2026-11-26.docx",
        OUT / "意义智能_书稿勘误与补充说明_2026-11-26.docx",
    ]
    records = [inspect_docx(path, required.get(path, []), strict=path in final_docx) for path in final_docx + supporting_docx]
    for record in records:
        is_final = (OUT / record["file"]) in final_docx
        record["role"] = "final" if is_final else "supporting_derived"
        record["generated_in_this_batch"] = True
    pdf_paths = [
        REPORT_DOCX.with_suffix(".pdf"),
        MANUAL_DOCX.with_suffix(".pdf"),
        OUT / "rendered" / "意义智能_附件衍生更新版_2026-11-26.pdf",
        OUT / "rendered" / "意义智能_书稿勘误与补充说明_2026-11-26.pdf",
    ]
    pdf_records = []
    for path, docx_path in zip(pdf_paths, final_docx + supporting_docx):
        if path.exists():
            record = inspect_pdf(path, strict=docx_path in final_docx)
            record["file"] = path.relative_to(OUT).as_posix()
            record["role"] = "final" if docx_path in final_docx else "supporting_derived"
            record["generated_in_this_batch"] = True
            pdf_records.append(record)
    records.extend(pdf_records)
    sources = []
    for path in (REPORT_MD, MANUAL_MD, Path(__file__)):
        sources.append({"file": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)})
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": "complete" if len(pdf_records) == 4 else "docx_complete_pdf_pending",
        "scope": "Final DOCX generation and local structural/PDF checks; GitHub and Function deployment are reported as prior evidence, while public access and production verification remain blocked.",
        "source_attachment_sha256_unchanged": sha256(SOURCE),
        "generator": "build_documents.py",
        "docx_library": "python-docx",
        "office_docx_tool_available": False,
        "pdf_renderer": "C:/Program Files/LibreOffice/program/soffice.exe",
        "supporting_documents_regenerated": True,
        "superseded_v2_excluded": True,
        "sources": sources,
        "documents": records,
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    build_attachment_update()
    build_supplement()
    manifest = build_manifest()
    (OUT / "document-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
