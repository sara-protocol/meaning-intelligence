# -*- coding: utf-8 -*-
"""构建双语切换版 index.html"""
import json, os, re, subprocess, sys

WS = r"C:\Users\gog98\Documents\lingxi-claw\users\247656584\projects\11955814199197869\workspace\意义智能"
SRC = os.path.join(WS, "有声读物_意义智能解读", "意义智能有声读物.html")
PUB = os.path.join(WS, "意义智能有声读物_发布包")

html = open(SRC, encoding="utf-8").read()
zh_cues = json.load(open(os.path.join(PUB, "subtitles.json"), encoding="utf-8"))
en_cues = json.load(open(os.path.join(PUB, "subtitles_en.json"), encoding="utf-8"))
en_tl = json.load(open(os.path.join(PUB, "timeline_en.json"), encoding="utf-8"))
en_chapters = en_tl["chapters"]
en_script = open(os.path.join(WS, "en_script.txt"), encoding="utf-8").read()
en_texts = [c.strip() for c in en_script.split("@@SEP@@") if len(c.strip()) > 200]

zh_tl = {"total": 2411, "chapters": [
 {"t": 0, "n": "第一章 · 为什么现在需要意义智能"},
 {"t": 301, "n": "第二章 · 核心理论体系"},
 {"t": 868, "n": "第三章 · 运行机制与工程化"},
 {"t": 1302, "n": "第四章 · 多尺度多领域实践"},
 {"t": 1560, "n": "第五章 · 文明演化总结与展望"},
 {"t": 1888, "n": "附录 · 实践工具与研究支撑"},
 {"t": 2182, "n": "全书总结 · 给智能装上方向舵"}]}

# ---- 图注中英对照 ----
CAPS = {
 "fig1-1_智能层级": ["图 1.1 智能的层级与意义智能的位置", "Figure 1.1 The Hierarchy of Intelligence and the Position of Meaning Intelligence"],
 "fig1-2_能做与值得做的断裂": ["图 1.2 “能做”与“值得做”的断裂", "Figure 1.2 The Gap Between “Can Do” and “Worth Doing”"],
 "fig2-1_四条公理": ["图 2.1 意义智能的四条公理及其关系", "Figure 2.1 The Four Axioms of Meaning Intelligence and Their Interrelations"],
 "fig3-1_意义光谱带": ["图 3.1 意义的三个层次（光谱带垂直结构）", "Figure 3.1 The Three Levels of Meaning (Spectral Band Vertical Structure)"],
 "fig4-1_五尺度导航模型": ["图 4.1 五尺度导航模型", "Figure 4.1 The Five-Scale Navigation Model"],
 "fig5-1_理论关系地图": ["图 5.1 意义智能与既有理论体系的关系地图", "Figure 5.1 The Relationship Map of Meaning Intelligence and Existing Theoretical Frameworks"],
 "fig7-1_MI引擎总体架构": ["图 7.1 MI引擎总体架构——三层次·三模块·四流程集成视图", "Figure 7.1 MI Engine Overall Architecture — Integrated View of Three Levels·Three Modules·Four Processes"],
 "fig7B-1_三大核心特性": ["图 7B.1 元认知觉察·螺旋上升·主动归零的关系", "Figure 7B.1 The Three Core Properties: Meta-Cognitive Awareness·Spiral Ascent·Active Zeroing"],
 "fig11-1_三级修正机制": ["图 11.1 三级修正机制的触发路径", "Figure 11.1 Trigger Pathways of the Three-Level Revision Mechanism"],
 "fig12-1_工程架构图": ["图 12.1 MI引擎工程架构图", "Figure 12.1 MI Engine Engineering Architecture Diagram"],
 "fig13-2_个人意义归零协议": ["图 13.2 个人意义归零协议的操作流程", "Figure 13.2 Operational Flow of Personal Meaning Zeroing Protocol"],
 "fig19-1_人机意义对齐螺旋": ["图 19.1 人机意义对齐的螺旋流程", "Figure 19.1 Spiral Process of Human-AI Meaning Alignment"],
 "fig24-2_四维同频演进与脱耦": ["图 24.2 文明四维度的同频演进与脱耦危机", "Figure 24.2 Synchronous Evolution and Decoupling Crises of Civilization's Four Dimensions"],
 "fig25-1_MI发展路线图": ["图 25.1 MI发展路线图五阶段全景（2026-2100+）", "Figure 25.1 Five-Stage Panorama of the MI Development Roadmap (2026-2100+)"],
 "figZ-1_文明自觉的黎明": ["图 终章.1 文明自觉的黎明——从盲目演化到自觉选择", "Figure Final.1 The Dawn of Civilizational Consciousness — From Blind Evolution to Conscious Choice"],
 "figC-1_元智能六层栈": ["图 C.1 元智能六层栈", "Figure C.1 The Meta-Intelligence Six-Layer Stack"],
 "figE-1_全书概念关系总览": ["图 E.1 MI专业术语概念图（全书概念关系总览）", "Figure F.1 MI Terminology Concept Map (Overview of Conceptual Relations)"],
}
# ---- 章节标题中英 ----
H = {
 "第一章 · 为什么现在需要意义智能": "Chapter 1 · Why We Need Meaning Intelligence Now",
 "第二章 · 核心理论体系": "Chapter 2 · The Core Theoretical System",
 "第三章 · 运行机制与工程化": "Chapter 3 · Mechanisms and Engineering",
 "第四章 · 多尺度多领域实践": "Chapter 4 · Multi-Scale, Multi-Domain Practice",
 "第五章 · 文明演化视角的总结与展望": "Chapter 5 · Civilizational Evolution and Outlook",
 "附录 · 实践工具与研究支撑": "Appendix · Tools and Research Support",
 "全书总结 · 给智能装上方向舵": "Full-Book Summary · A Rudder for Intelligence",
}
UI = {
 "hero_h1": ["《意义智能》：给智能装上方向舵", "Meaning Intelligence: A Rudder for Intelligence"],
 "hero_sub": ["意义文明的认知操作系统 · 全书解读有声读物（中文讲解 40:11 / English narration 18:54）",
              "The Cognitive Operating System of the Meaning Civilization · Audio Companion (English 18:54 / 中文 40:11)"],
 "hero_tag": ["可视 · 可听 · 可读 一体化解读", "Visual · Audio · Readable — Bilingual Edition"],
 "play_btn": ["🎧 播放全书讲解（中文）", "🎧 Play Full Narration (English)"],
 "sub_hint": ["播放后此处将同步显示字幕", "Subtitles will appear here during playback"],
 "ch_hint": ["点击下方章节，或直接播放——画面会随讲解自动同步", "Click a chapter below or press play"],
 "transcript": ["讲解文稿", "Transcript"],
}

# ---- 资源路径改写 ----
html = re.sub(r'src="([^"/:]+)\.png"', r'src="assets/\1.jpg"', html)
html = html.replace('src="assets/cover.jpg.jpg"', 'src="assets/cover.jpg"')
html = html.replace('src="cover.jpg"', 'src="assets/cover.jpg"')
html = html.replace('src="audio.mp3"', 'src="assets/audio-web.mp3"')

# ---- 语言切换按钮 ----
toggle = """<div style="position:fixed;top:14px;right:16px;z-index:98;display:flex;gap:0;
border:1px solid var(--gold);border-radius:999px;overflow:hidden;background:rgba(11,16,32,.85);backdrop-filter:blur(4px)">
<button id="btnZh" onclick="setLang('zh')" class="lng on">中文</button>
<button id="btnEn" onclick="setLang('en')" class="lng">EN</button></div>
<style>.lng{background:transparent;border:none;color:var(--dim);padding:7px 16px;cursor:pointer;font-size:14px}
.lng.on{background:var(--gold);color:#0b1020;font-weight:bold}</style>"""
html = html.replace("<body>", "<body>\n" + toggle)

# ---- 字幕条 ----
ui = '<div id="subBar" style="margin-top:12px;min-height:56px;background:rgba(0,0,0,.45);border:1px solid var(--line);border-radius:10px;padding:12px 18px;font-size:17px;line-height:1.7;color:#fff;text-align:center;letter-spacing:.5px">播放后此处将同步显示字幕</div>'
html = html.replace('<div class="chapters" id="chapters"></div>',
                    '<div class="chapters" id="chapters"></div>\n' + ui)

# ---- 文稿标题双语属性 ----
html = re.sub(r'<summary>([^<]*?)( · 讲解文稿)?</summary>',
              lambda m: f'<summary data-zh="{m.group(1)}{m.group(2) or " · 讲解文稿"}" data-en="{H.get(m.group(1), m.group(1))} · Transcript">{m.group(1)}{m.group(2) or " · 讲解文稿"}</summary>', html)

# ---- 双语脚本 ----
i18n = {
 "zh": {"audio": "assets/audio-web.mp3", "tl": zh_tl, "cues": zh_cues, "texts": None},
 "en": {"audio": "assets_en/audio_en.mp3", "tl": en_tl, "cues": en_cues, "texts": en_texts},
}
data = {"caps": {k: v for k, v in CAPS.items()}, "heads": H, "ui": UI, "i18n": {k: {"audio": v["audio"], "tl": v["tl"], "texts": v["texts"]} for k, v in i18n.items()}}
cues_js = {"zh": zh_cues, "en": en_cues}

engine = """
<div id="biData" style="display:none">__DATA__</div>
<div id="cuesData" style="display:none">__CUES__</div>
<script>
const BI=JSON.parse(document.getElementById('biData').textContent);
const CUES2=JSON.parse(document.getElementById('cuesData').textContent);
let LANG='zh';
const $=id=>document.getElementById(id);
function fmtT(s){s=Math.floor(s);return String(Math.floor(s/60)).padStart(2,'0')+":"+String(s%60).padStart(2,'0');}
function renderChapters(){
  const tl=BI.i18n[LANG].tl;const box=$('chapters');box.innerHTML='';
  tl.chapters.forEach(c=>{
    const b=document.createElement('button');b.className='chap';
    b.innerHTML='<span class="t">'+fmtT(c.t)+'</span><span class="n">'+c.n+'</span>';
    b.onclick=()=>{audio.currentTime=c.t;audio.play();};
    box.appendChild(b);
  });sync();
}
function setLang(l){
  if(l===LANG)return;const was=audio.currentTime;
  audio.pause();LANG=l;
  $('btnZh').classList.toggle('on',l==='zh');$('btnEn').classList.toggle('on',l==='en');
  audio.src=BI.i18n[l].audio;
  // 标题
  document.querySelector('.hero h1').textContent=BI.ui.hero_h1[l==='zh'?0:1];
  document.querySelector('.hero .sub').textContent=BI.ui.hero_sub[l==='zh'?0:1];
  document.querySelector('.hero .tag').textContent=BI.ui.hero_tag[l==='zh'?0:1];
  document.querySelector('#player b').textContent=BI.ui.play_btn[l==='zh'?0:1];
  $('subBar').textContent=BI.ui.sub_hint[l==='zh'?0:1];
  // 章节标题
  document.querySelectorAll('h2.sec').forEach(h=>{const zh=h.getAttribute('data-zh')||h.textContent;h.setAttribute('data-zh',zh);h.textContent=l==='zh'?zh:(BI.heads[zh]||zh);});
  // 图注与图片
  document.querySelectorAll('.figs figure').forEach(f=>{
    const img=f.querySelector('img');if(!img)return;
    const base=img.getAttribute('data-base');if(!base)return;
    img.src=(l==='zh'?'assets/':'assets_en/img/')+base+'.jpg';
    const cap=f.querySelector('figcaption');
    const c=BI.caps[base];
    if(c){const full=(l==='zh'?c[0]:c[1]);const m=full.match(/^((?:图|Figure)[^ ]*(?:\.[^ ]*)?)\s+(.*)$/);
      cap.innerHTML=m?('<b>'+m[1]+'</b> '+m[2]):full;}
  });
  // 文稿
  const blocks=document.querySelectorAll('details');
  let bi=0;
  blocks.forEach(d=>{
    const sum=d.querySelector('summary');
    const zh=sum.getAttribute('data-zh');
    sum.textContent=l==='zh'?zh:(BI.heads[zh]?BI.heads[zh]+' · Transcript':zh);
    if(l==='en'&&BI.i18n.en.texts&&bi<BI.i18n.en.texts.length){
      const dv=d.querySelector('.script');
      if(dv){dv.setAttribute('data-zh-script',dv.getAttribute('data-zh-script')||dv.textContent);
        if(dv.dataset.orig===undefined)dv.dataset.orig=dv.textContent;
        // 按顺序：details块=7章文稿
      }
      bi++;
    }
  });
  if(l==='en'){const all=document.querySelectorAll('details .script');all.forEach((dv,i)=>{if(!dv.dataset.orig)dv.dataset.orig=dv.textContent;if(BI.i18n.en.texts[i])dv.textContent=BI.i18n.en.texts[i];});}
  else{document.querySelectorAll('details .script').forEach(dv=>{if(dv.dataset.orig)dv.textContent=dv.dataset.orig;});}
  document.documentElement.lang=l==='zh'?'zh-CN':'en';
  renderChapters();
}
// 图注 base 标记
document.querySelectorAll('.figs img').forEach(img=>{
  img.setAttribute('data-base',img.src.split('/').pop().replace('.jpg','').replace('.png',''));
});
// 字幕
const sub=$('subBar');
audio.addEventListener('timeupdate',()=>{
  const t=audio.currentTime;const cs=CUES2[LANG];
  const c=cs.find(c=>t>=c.s&&t<c.e);
  sub.textContent=c?c.t:sub.textContent;
});
renderChapters();
</script>
"""
data_js = json.dumps(data, ensure_ascii=False)
cues_js_s = json.dumps(cues_js, ensure_ascii=False)
html = html.replace("</body>", engine.replace("__DATA__", data_js).replace("__CUES__", cues_js_s) + "</body>")
html = html.replace("<html lang=\"zh-CN\">", "<html lang=\"zh-CN\">")

open(os.path.join(PUB, "index.html"), "w", encoding="utf-8").write(html)
finalizer = os.path.join(WS, "meaning-intelligence-publish", "scripts", "finalize_publish.py")
subprocess.run([sys.executable, finalizer], check=True)
print("双语 index.html 完成,", len(html)//1024, "KB")
