\# Claim Registry

> **来源边界**：MI-C001–MI-C012 是项目 claim registry，不自动等于正典 H1–H18。
> 六层栈是本项目工程扩展（E0），不是正典固定层次；正典关联与工程操作化必须分开标注。



> **本文件是整个研究系统的核心数据库。**

> 每一个理论主张在这里有一个唯一 ID。论文、网站、白皮书、实验、工具

> 都应引用 **claim ID**（如 `MI-C003`），而不是笼统引用「L6」或「六层栈」。

>

> **编号规则**：新增 claim 从 `MI-C100` 起，既有编号永不重排。

> 撤销的 claim 保留编号,状态改为 `Withdrawn`。



---



## 状态与证据等级



### Evidence Status（E0–E6）



| 等级 | 名称 | 含义 |

|---|---|---|

| E0 | Conceptual | 概念已定义,未形式化 |

| E1 | Formalized | 已形式化(有精确定义、可测量变量) |

| E2 | Operationalized | 已操作化(有量表、工具、可复现流程) |

| E3 | Predictive | 有预注册假设，数据收集中 |

| E4 | Replicated | 已被独立研究复现 |

| E5 | Tested / Falsified | 已通过预注册检验,或已被证伪 |

| E6 | Externally Validated | 跨情境、跨文化、跨时间泛化 |



### Claim Status



| 状态 | 含义 |

|---|---|

| `Draft` | 已草拟,尚未正式发布 |

| `Formalized` | 已形式化,等待操作化 |

| `Under Test` | 有正在进行的检验 |

| `Survived` | 已通过预注册检验 |

| `Falsified` | 已被证伪(见 `docs/failure-matrix.md`) |

| `Withdrawn` | 主动撤回 |



---



## 索引



| ID | 一句话陈述 | 证据 | 状态 |

|---|---|---|---|

| [MI-C001](#mi-c001) | 意义智能是对其他智能活动的方向性调控 | E1 | Formalized |

| [MI-C002](#mi-c002) | 意义智能是元层,不与 IQ/EQ/SQ 并列 | E1 | Formalized |

| [MI-C003](#mi-c003) | 意义判断可分解为方向·价值·边界 | E0–E1 | Formalized |

| [MI-C004](#mi-c004) | 意义沿一条连续光谱带分布,而非离散层次 | E0 | Draft |

| [MI-C005](#mi-c005) | 多尺度意义不可通约,协调不是加权求和 | E1 | Formalized |

| [MI-C006](#mi-c006) | 递归审视改善长期决策质量 | E2 | Under Test |

| [MI-C007](#mi-c007) | 六层栈是一种有效的操作性表示 | E0 | Draft |

| [MI-C008](#mi-c008) | 减负改善决策质量(相对纯信息呈现) | E1 | Under Test |

| [MI-C009](#mi-c009) | 可体验(交互)提升结构回忆 | E1 | Under Test |

| [MI-C010](#mi-c010) | 跨尺度一致性预测系统生存 | E1 | Under Test |

| [MI-C011](#mi-c011) | 主动归零缓解长期僵化 | E2 | Under Test |

| [MI-C012](#mi-c012) | 无归零导致僵化 | E1 | Formalized |



---



## 核心定义 / Core Definitions



<a id="mi-c001"></a>

### MI-C001 — 意义智能的定义



**陈述**



> 意义智能是对其他智能活动的**方向性调控**。

> 它追问的不是「能不能做到」,而是「值不值得做,对谁值得,在什么尺度上值得」。



**正典关联**：§1.3



**Evidence Status**：E1 (Formalized)

**Claim Status**：Formalized



**测试方式**

Construct validation:检查「方向性调控」是否构成一个可独立测量、且区别于 IQ / EQ / SQ 的构念。



**失败条件**

若「方向性调控」无法被独立测量,或与 IQ / EQ / SQ 的测量高度共线(相关系数 > 0.8),则本 claim 被证伪。



---



<a id="mi-c002"></a>

### MI-C002 — 元层关系



**陈述**



> 意义智能与 IQ / EQ / SQ 的关系不是**并列**,而是**嵌套与约束**。

> 它是元层,不是第四类智能。



**正典关联**：§1.3



**Evidence Status**：E1

**Claim Status**：Formalized



**测试方式**

Hierarchical factor analysis: 检验「方向性调控」是否在上层因子结构中对 IQ / EQ / SQ 有约束效应。



**失败条件**

若「方向性调控」在因子结构中与 IQ / EQ / SQ 处于同一层级,则本 claim 被证伪。



---



## 理论模型 / Theoretical Model



<a id="mi-c003"></a>

### MI-C003 — 意义判断的三维度



**陈述**



> 一次意义判断可以沿三个维度分解：**方向(Direction)、价值(Value)、边界(Boundary)**。



**正典关联**：§3.2

**注意**：不要与 §8.2 的「四维度 C/V/E/A」混淆——那是用于系缚强度(BS)分析的另一组维度。



**Evidence Status**：E0–E1

**Claim Status**：Formalized



**测试方式**

Factor / structural validation: 用验证性因子分析(CFA)检验三维度结构,要求 CFI > 0.90, RMSEA < 0.08。



**失败条件**

若意义判断的方差被单一维度解释 > 90%,三维度结构不成立,本 claim 被证伪。



---



<a id="mi-c004"></a>

### MI-C004 — 意义光谱带



**陈述**



> 意义的分布是一条**连续光谱带**,而不是三个离散层次。

> 原「元意义层」在光谱带抽象端,原「情境意义层」在具体端,中间无断层。



**正典关联**：§3.1(原始离散模型) + §8.1(V7 光谱带模型)

**注意**：V7 的第 8 章 8.1 明确「光谱带模型取代固定层次」。



**Evidence Status**：E0

**Claim Status**：Draft



**测试方式**

Longitudinal study: 追踪个体/组织的意义判断,检验其抽象度与时间跨度是否呈连续分布,而非三聚类。



**失败条件**

若意义判断在抽象度-时距空间中被聚类为恰好三个紧密簇(cluster separation > 2σ),则光谱带模型被证伪,退回离散模型。



---



<a id="mi-c005"></a>

### MI-C005 — 多尺度不可通约



**陈述**



> 多尺度意义(个人 / 组织 / 城市 / 国家 / 人类)**不可通约**。

> 跨尺度协调**不是**加权求和。



**正典关联**：第 4 章;公理三



**Evidence Status**：E1

**Claim Status**：Formalized



**测试方式**

Multi-scale decision experiment: 观察当个人尺度与组织尺度方向冲突时,加权求和模型 vs 递归校准模型,哪个能预测实际决策。



**失败条件**

若加权求和模型在多尺度冲突情境中的预测力显著高于递归校准模型,本 claim 被证伪。



---



## 六层操作化 / Operational Stack



> **声明**：六层栈本身是一个**整合结构**,证据等级 E0。

> 以下 claims 分别描述每一层可能带来的效应,而不是宣称整个栈已被证实。



<a id="mi-c006"></a>

### MI-C006 — 递归审视改善长期决策质量



**陈述**



> 递归审视(Recursive Review)改善长时段的决策质量。



**正典关联**：三特性 MCA/SA/AZ;§7B.2–§7B.4;H12/H13/H14



**Evidence Status**：E2

**Claim Status**：Under Test



**测试方式**

RCT(随机对照实验): 干预组加入递归审视流程,对照组不加入。测量: 长期决策质量、方向偏离、沉没成本持续、价值错位。



**失败条件**

若 RCT 效应量 **d < 0.3**(或等价统计阈值),本 claim 被证伪,递归审视降为**可选规程**,不再作为有效性主张。



---



<a id="mi-c007"></a>

### MI-C007 — 六层栈的有效性



**陈述**



> 六层栈(L1–L6)是一种**有效的**操作性表示。



**正典关联**：本 white paper 提出的整合结构



**Evidence Status**：**E0(概念)** —— 未经独立检验

**Claim Status**：Draft



**测试方式**

Comparative study: 用六层栈指导的决策 vs 用其他分层框架(如 OODA、Cynefin)指导的决策 vs 无框架决策,比较决策质量与方向一致性。



**失败条件**

若六层栈指导组在决策质量上**未显著优于**无框架组,或**未优于**已有框架,本 claim 被证伪,六层栈应被替换而非辩护。



---



<a id="mi-c008"></a>

### MI-C008 — 减负改善决策质量



**陈述**



> 认知负荷降低(受控语言、字数硬限、事实/问题分离)改善决策质量,相对纯信息呈现。



**正典关联**：§1.1;工具 A.1



**Evidence Status**：E1(框架内操作化;外部机制待按 V7.0 逐条核验)

**Claim Status**：Under Test



**测试方式**

Controlled experiment: 同一份材料,一组用 ASD-STE100 风格压缩,一组保持原文。测量决策质量、误读率、决策信心校准。



**失败条件**

若降维组与原文组的决策质量无显著差异(d < 0.3),本 claim 被证伪,应重设压缩比或放弃字数硬限。



---



<a id="mi-c009"></a>

### MI-C009 — 可体验提升结构回忆



**陈述**



> 交互式呈现(可操作、可回放)提升对抽象结构的回忆,相对静态文本呈现。



**正典关联**：第 3 章;第 9 章 M1



**Evidence Status**：E1(框架内操作化;外部机制待按 V7.0 逐条核验)

**Claim Status**：Under Test



**测试方式**

Controlled study: 交互组 vs 静态组,测量结构回忆(延迟 1 周)、迁移能力。



**失败条件**

若交互组与静态组的回忆无显著差异,本 claim 被证伪,交互式呈现降为**可选增强**,不作必需层。



---



<a id="mi-c010"></a>

### MI-C010 — 跨尺度一致性预测生存



**陈述**



> 在跨尺度(个人/组织/城市/国家/人类)上方向一致的系统,生存期更长。



**正典关联**：第 4 章;H7



**Evidence Status**：E1

**Claim Status**：Under Test



**测试方式**

Longitudinal study: 追踪多组织的方向一致性指标(DC)与其生存期(或绩效持续期)的相关。



**失败条件**

若长期方向背离却无危机(H8 反例),本 claim 被证伪,需重估五尺度模型。



---



<a id="mi-c011"></a>

### MI-C011 — 主动归零缓解僵化



**陈述**



> 周期性主动归零(Active Zeroing)缓解组织的长期僵化。



**正典关联**：§7B.4;工具 A.10;H12



**Evidence Status**：E2(案例支持)

**Claim Status**：Under Test



**测试方式**

RCT(进行中): 干预组引入年度归零流程,对照组不引入。测量: 战略漂移、承诺升级、价值错位。



**失败条件**

若 RCT 无显著差异(d < 0.3),本 claim 被证伪,归零降为**操作规程**,不再主张有效性。



---



<a id="mi-c012"></a>

### MI-C012 — 无归零导致僵化



**陈述**



> 缺乏周期性归零的系统趋向僵化。



**正典关联**：H14



**Evidence Status**：E1

**Claim Status**：Formalized



**测试方式**

Observational study: 观察长期无归零机制的组织,追踪僵化指标(决策滞后、创新下降、价值错位)。



**失败条件**

若长期无归零的组织未显示僵化迹象,本 claim 被证伪,H14 应被修订。



---



## 引用方式



在论文、白皮书、网站、实验中引用本理论时,请使用 **claim ID**：



> ✅ "意义判断可分解为方向、价值、边界三个维度 **[MI-C003]**。"

> ✅ "递归审视改善长期决策质量 **[MI-C006]**,但当前证据等级为 E2,处于 Under Test 状态。"



> ❌ "六层栈的 L6 层说递归审视有用。"（未引用 claim ID,无法追溯到证据等级与失败条件）



---



## 更新规程



1. **新增 claim**：从 `MI-C100` 开始,序号递增,**不重用**旧编号。

2. **修改 claim**：修改内容但不改 ID,在文档末尾 "Revision Log" 追加记录。

3. **证伪 claim**：状态改为 `Falsified`,**保留**在文档中(不删除),按 `docs/failure-matrix.md` 的规则处理。

4. **撤回 claim**：状态改为 `Withdrawn`,保留编号与简短理由。



---



## 与其它文档的关系



| 文档 | 作用 |

|---|---|

| **本文件 `claims.md`** | Claim 的唯一真相源 |

| [`evidence.md`](evidence.md) | E0–E6 的详细判据 |

| [`failure-matrix.md`](failure-matrix.md) | 每个 claim 达到失败阈值后的处理规程 |

| [`glossary.md`](glossary.md) | 术语与正典章节对照 |

| [`architecture.md`](architecture.md) | 六层栈与正典机制的映射 |



---



## Revision Log



| 日期 | Claim ID | 变更 | 理由 |

|---|---|---|---|

| 2026-10-08 | — | 初版创建,12 个 claims | P0-06 首次建立 |



---



*本文件遵循可失败性承诺：claim 达到失败阈值时,将被标记或删除,而不是被辩护。*

