#!/usr/bin/env python3
"""Build or verify the Meaning Intelligence explainer video.

The current release is the 164-second bilingual master. Run without arguments to
verify it and refresh its subtitles, narration, chapter manifest, and evidence
report. The older 154-second English-dubbing builder remains available explicitly
through --build-legacy; it must not be used as the current release pipeline.

Commands:
    python build_video.py
    python build_video.py --verify-release
    python build_video.py --build-legacy [--force-audio]
    python build_video.py --build-legacy --verify-only
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import textwrap
import wave
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "meaning_intelligence_launch.mp4"
SOURCE_SHA256 = "71f00d1c046bb959a4afe6f2d70b94ccb417e82e5f75ed60393d4a664c0991b4"
EN_VIDEO = ROOT / "meaning_intelligence_launch_en.mp4"
EN_WAV = ROOT / "narration_en.wav"
ZH_WAV = ROOT / "narration_zh.wav"
EN_SRT = ROOT / "subtitles.en.srt"
EN_VTT = ROOT / "subtitles.en.vtt"
ZH_SRT = ROOT / "subtitles.zh.srt"
ZH_VTT = ROOT / "subtitles.zh.vtt"
PLAYER = ROOT / "player.html"
AUDIO_BUILD = ROOT / "build" / "english_audio"
VERIFICATION = ROOT / "build" / "verification.json"
RELEASE_ZH = ROOT / "meaning_intelligence_zh.mp4"
RELEASE_EN = ROOT / "meaning_intelligence_en.mp4"
RELEASE_HASHES = {
    RELEASE_ZH.name: "a4de33c434daf16d727b1f5ab12ed65d0b19eacb0aad0e93f07475d96b5a535d",
    RELEASE_EN.name: "c225ad9cb95b555774ea7dfda2a1e08661de7c9467743359847efd6acfe209d3",
}
RELEASE_DURATION = 164.010667
RELEASE_CHAPTERS: list[dict[str, Any]] = [
    {"number": 1, "start": 0, "end": 11, "title_zh": "意义智能", "title_en": "Meaning Intelligence"},
    {"number": 2, "start": 11, "end": 23, "title_zh": "能力与值得性", "title_en": "Capability vs. Worth"},
    {"number": 3, "start": 23, "end": 36, "title_zh": "“意义”的含义", "title_en": "What “Meaning” Means"},
    {"number": 4, "start": 36, "end": 49, "title_zh": "意义势能", "title_en": "Meaning Potential"},
    {"number": 5, "start": 49, "end": 63, "title_zh": "意义智能运行机制", "title_en": "The MI Engine"},
    {"number": 6, "start": 63, "end": 79, "title_zh": "可运行的智能体", "title_en": "A Runnable Agent"},
    {"number": 7, "start": 79, "end": 99, "title_zh": "六层工程栈", "title_en": "The Six-Layer Stack"},
    {"number": 8, "start": 99, "end": 113, "title_zh": "五尺度导航", "title_en": "Five-Scale Navigation"},
    {"number": 9, "start": 113, "end": 126, "title_zh": "方向、价值、边界", "title_en": "Direction, Value, Boundary"},
    {"number": 10, "start": 126, "end": 140, "title_zh": "主动归零", "title_en": "Active Zeroing"},
    {"number": 11, "start": 140, "end": 153, "title_zh": "意义自检", "title_en": "A Meaning Self-Check"},
    {"number": 12, "start": 153, "end": 164, "title_zh": "迈向值得的方向", "title_en": "Toward What Is Worthwhile"},
]

SAMPLE_RATE = 48000
LEAD = 0.22
TAIL = 0.55
GAP = 0.10
SAPI_RATE = 1
MIN_SPEED = 0.90
MAX_SPEED = 1.32
SILENCE_DB = -45.0
SILENCE_SECONDS = 3.0

# One spoken sentence per subtitle cue. Cue counts match the verified Chinese SRT.
ENGLISH_CHAPTERS: list[dict[str, Any]] = [
    {
        "title_en": "Meaning Intelligence: A Rudder for Intelligence",
        "cues": [
            "Meaning Intelligence is a launch about direction.",
            "It asks not what more machines can do, but what is worth doing as capability grows.",
            "Next, eleven pages trace the key path from theory to engineering.",
        ],
    },
    {
        "title_en": "Capability Can Grow While Direction Is Missing",
        "cues": [
            "Growing capability does not automatically bring clear direction.",
            "Action can expand faster than cognition, governance, and meaning coordination.",
            "The result can be capability without clarity about what is worth doing.",
            "Meaning Intelligence adds a continuous audit of direction.",
        ],
    },
    {
        "title_en": "Meaning Intelligence: Directional Control",
        "cues": [
            "Meaning Intelligence directs intelligent activity; it is not a fourth intelligence.",
            "At the meta level, it examines direction, value, and boundaries to guide worthwhile action.",
            "It does not replace expertise or promise a single answer.",
        ],
    },
    {
        "title_en": "A Continuous Spectrum Replaces Three Fixed Levels",
        "cues": [
            "Chapter eight of the Version Seven canon reframes meta-meaning, mediating meaning, and situational meaning.",
            "Instead of three fixed levels, it proposes a continuous spectrum from abstract, long-term to concrete, short-term.",
            "This spectrum is not the six-layer engineering stack.",
        ],
    },
    {
        "title_en": "The Six-Layer Engineering Stack: An E0 Organizing Tool",
        "cues": [
            "The six-layer stack is an organizing tool proposed by the engineering team; overall, it remains E-zero, not a fixed canonical layer.",
            "Load reduction and experience form one band.",
            "Meaning generation and value assessment form another; direction choice and reflective review form the third.",
            "A better partition could replace it.",
        ],
    },
    {
        "title_en": "The Four-Process Engine: Turning Uncertainty into a Loop",
        "cues": [
            "The four-process engine forms a closed loop.",
            "F-one identifies what is involved and handles cognitive uncertainty; F-two evaluates meaning and handles value uncertainty.",
            "F-three decides how to act and handles existential uncertainty.",
            "F-four revises through feedback and handles action uncertainty.",
        ],
    },
    {
        "title_en": "MCA / SA / AZ: Keeping Direction Revisable",
        "cues": [
            "Three features keep direction open to revision.",
            "Metacognitive awareness examines the framework of judgment.",
            "Spiral ascent returns to the problem without repeating in place; active zeroing clears an outdated structure before collapse, rather than waiting for it.",
            "Together, they prevent direction from becoming rigid.",
        ],
    },
    {
        "title_en": "Five-Scale Recalibration, Not Weighted Summation",
        "cues": [
            "Across five scales—individual, organization, city, nation, and civilization—each has a meaning logic that cannot be reduced to the others.",
            "Upward emergence and downward influence are not a simple sum.",
            "In conflict, do not take a weighted average; return to meta-meaning for dynamic ordering and staged recalibration.",
        ],
    },
    {
        "title_en": "Be Honest About Evidence and Failure",
        "cues": [
            "Evidence levels describe the state of knowledge, not a quality score.",
            "E-three means preregistration plus data collection, not predictive success; E-five includes falsification or survival.",
            "Canonical H-one through H-eighteen and engineering drafts remain separate; without preregistration, there is no formal disposition.",
        ],
    },
    {
        "title_en": "A Runnable Agent with Human Approval",
        "cues": [
            "A runnable agent turns materials and constraints into structured judgment, offering direction, reasons, evidence, and options with a feedback path.",
            "It is an engineering demonstration, not proof that the theory holds.",
            "Critical actions require human approval.",
            "The system remains traceable and vetoable.",
        ],
    },
    {
        "title_en": "Start with One Real Task and Clear Boundaries",
        "cues": [
            "To begin, choose one small, high-value decision that can be reviewed.",
            "Record direction, value, boundaries, and evidence level; run the four-process loop, then expand gradually.",
            "Meaning Intelligence provides a rudder; it does not replace the operator's judgment and responsibility.",
        ],
    },
]


def run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, check=True, text=True, encoding="utf-8", errors="replace", **kwargs)


def probe(path: Path) -> dict[str, Any]:
    out = run(["ffprobe", "-v", "error", "-show_chapters", "-show_streams", "-show_format", "-of", "json", str(path)], capture_output=True)
    return json.loads(out.stdout)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def stream_hash(path: Path, stream: str) -> str:
    out = run(["ffmpeg", "-v", "error", "-i", str(path), "-map", stream, "-c", "copy",
               "-f", "hash", "-hash", "sha256", "-"], capture_output=True)
    return out.stdout.strip().split("=")[-1]


def srt_time(seconds: float) -> str:
    milliseconds = int(round(seconds * 1000))
    hours, milliseconds = divmod(milliseconds, 3_600_000)
    minutes, milliseconds = divmod(milliseconds, 60_000)
    secs, milliseconds = divmod(milliseconds, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{milliseconds:03d}"


def vtt_time(seconds: float) -> str:
    return srt_time(seconds).replace(",", ".")


def parse_time(value: str) -> float:
    hours, minutes, rest = value.strip().split(":")
    seconds, milliseconds = re.split(r"[,.]", rest)
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(milliseconds) / 1000


def parse_srt_text(text: str) -> list[dict[str, Any]]:
    cues: list[dict[str, Any]] = []
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    for block in normalized.split("\n\n"):
        lines = block.splitlines()
        if len(lines) < 3:
            continue
        start, end = lines[1].split(" --> ")
        cues.append({"start": parse_time(start), "end": parse_time(end), "text": "\n".join(lines[2:])})
    return cues


def parse_srt(path: Path) -> list[dict[str, Any]]:
    return parse_srt_text(path.read_text(encoding="utf-8-sig"))


def wrap_cue(text: str, width: int = 80) -> str:
    if len(text) <= width:
        return text
    words = text.split()
    midpoint = len(text) / 2
    splits = []
    for index in range(1, len(words)):
        left = " ".join(words[:index])
        right = " ".join(words[index:])
        longest = max(len(left), len(right))
        if longest <= width:
            splits.append((longest, abs(len(left) - len(right)) - abs(len(left) - midpoint), left, right))
    if not splits:
        raise RuntimeError(f"Subtitle cue needs more than two balanced lines: {text}")
    _, _, left, right = min(splits)
    return f"{left}\n{right}"


def write_subtitles(cues: list[dict[str, Any]], srt_path: Path, vtt_path: Path) -> None:
    blocks = [f"{i}\n{srt_time(c['start'])} --> {srt_time(c['end'])}\n{c['text']}\n" for i, c in enumerate(cues, 1)]
    srt_path.write_text("\n".join(blocks), encoding="utf-8")
    vtt = ["WEBVTT", ""]
    for cue in cues:
        vtt.extend([f"{vtt_time(cue['start'])} --> {vtt_time(cue['end'])}", cue["text"], ""])
    vtt_path.write_text("\n".join(vtt), encoding="utf-8")


def write_narration(manifest: dict[str, Any]) -> None:
    en_lines = ["意义智能 / Meaning Intelligence — Illustrated Explainer", "Narration: en", ""]
    zh_lines = ["意义智能 / Meaning Intelligence — Illustrated Explainer", "Narration: zh", ""]
    for page, chapter in zip(manifest["pages"], ENGLISH_CHAPTERS, strict=True):
        heading = f"{page['page']:02d}  {page['title']} / {chapter['title_en']}"
        en_lines.extend([heading, " ".join(chapter["cues"]), ""])
        zh_lines.extend([heading, page["narration_text"], ""])
    (ROOT / "narration_en.txt").write_text("\n".join(en_lines), encoding="utf-8")
    (ROOT / "narration_zh.txt").write_text("\n".join(zh_lines), encoding="utf-8")


def discover_english_voice() -> dict[str, str]:
    script = (
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "$s.GetInstalledVoices() | ForEach-Object { "
        "$v = $_.VoiceInfo; [PSCustomObject]@{Name=$v.Name; Culture=$v.Culture.Name; Gender=$v.Gender} "
        "} | ConvertTo-Json -Compress"
    )
    result = run(["powershell.exe", "-NoProfile", "-Command", script], capture_output=True)
    voices = json.loads(result.stdout or "null")
    if voices is None:
        voices = []
    elif isinstance(voices, dict):
        voices = [voices]
    english = [voice for voice in voices if voice.get("Culture", "").lower().startswith("en-")]
    if not english:
        raise RuntimeError("No local English Windows SAPI voice is installed")
    preferred = next((voice for voice in english if voice["Name"] == "Microsoft Zira Desktop"), english[0])
    return {"name": preferred["Name"], "culture": preferred["Culture"], "engine": "Windows SAPI / System.Speech"}


def synthesize_missing(jobs: list[dict[str, str]], voice: dict[str, str]) -> None:
    if not jobs:
        return
    jobs_path = AUDIO_BUILD / "sapi_jobs.json"
    script_path = AUDIO_BUILD / "synthesize.ps1"
    jobs_path.write_text(json.dumps(jobs, ensure_ascii=False, indent=2), encoding="utf-8")
    safe_voice = voice["name"].replace("'", "''")
    script = f"""$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$jobs = Get-Content -LiteralPath '{jobs_path.as_posix()}' -Raw -Encoding UTF8 | ConvertFrom-Json
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$voice = $synth.GetInstalledVoices() | Where-Object {{ $_.VoiceInfo.Name -eq '{safe_voice}' }} | Select-Object -First 1
if (-not $voice) {{ throw 'Required local English SAPI voice is unavailable' }}
$synth.SelectVoice($voice.VoiceInfo.Name)
$synth.Rate = {SAPI_RATE}
$synth.Volume = 100
foreach ($job in $jobs) {{
    $synth.SetOutputToWaveFile($job.output)
    $synth.Speak($job.text)
}}
$synth.SetOutputToNull()
$synth.Dispose()
"""
    script_path.write_text(script, encoding="utf-8-sig")
    run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path)], capture_output=True)


def trim_silence(source: Path, target: Path) -> None:
    filters = (
        "silenceremove=start_periods=1:start_duration=0:start_threshold=-50dB:start_silence=0.02,"
        "areverse,"
        "silenceremove=start_periods=1:start_duration=0:start_threshold=-50dB:start_silence=0.04,"
        "areverse,aresample=48000,aformat=sample_fmts=s16:channel_layouts=mono"
    )
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(source), "-af", filters,
         "-ar", str(SAMPLE_RATE), "-ac", "1", "-c:a", "pcm_s16le", str(target)])


def change_tempo(source: Path, target: Path, speed: float) -> None:
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
         "-af", f"atempo={speed:.8f},aresample=48000,aformat=sample_fmts=s16:channel_layouts=mono",
         "-ar", str(SAMPLE_RATE), "-ac", "1", "-c:a", "pcm_s16le", str(target)])


def read_pcm(path: Path) -> bytes:
    with wave.open(str(path), "rb") as handle:
        if handle.getframerate() != SAMPLE_RATE or handle.getnchannels() != 1 or handle.getsampwidth() != 2:
            raise RuntimeError(f"Unexpected WAV format: {path}")
        return handle.readframes(handle.getnframes())


def build_english_audio(manifest: dict[str, Any], source_info: dict[str, Any], force: bool) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    voice = discover_english_voice()
    raw_dir = AUDIO_BUILD / "raw"
    trimmed_dir = AUDIO_BUILD / "trimmed"
    timed_dir = AUDIO_BUILD / "timed"
    for directory in (raw_dir, trimmed_dir, timed_dir):
        directory.mkdir(parents=True, exist_ok=True)

    pages = manifest["pages"]
    if len(pages) != len(ENGLISH_CHAPTERS):
        raise RuntimeError("Manifest page count does not match the English script")
    chinese_cues = parse_srt(ROOT / "meaning_intelligence_launch.zh.srt")
    if sum(len(chapter["cues"]) for chapter in ENGLISH_CHAPTERS) != len(chinese_cues):
        raise RuntimeError("English cue count does not match the verified Chinese SRT")

    jobs: list[dict[str, str]] = []
    entries: list[list[dict[str, Any]]] = []
    for page_index, (page, chapter) in enumerate(zip(pages, ENGLISH_CHAPTERS, strict=True), 1):
        if len(chapter["cues"]) != int(page["subtitle_cue_count"]):
            raise RuntimeError(f"Page {page_index} English/Chinese cue count mismatch")
        chapter_entries: list[dict[str, Any]] = []
        for cue_index, text in enumerate(chapter["cues"], 1):
            digest = hashlib.sha256((text + voice["name"] + str(SAPI_RATE)).encode("utf-8")).hexdigest()
            stem = f"p{page_index:02d}_c{cue_index:02d}_{digest[:12]}"
            raw = raw_dir / f"{stem}.wav"
            trimmed = trimmed_dir / f"{stem}.wav"
            if force or not raw.exists() or raw.stat().st_size < 1000:
                jobs.append({"text": text, "output": raw.as_posix(), "sha256": digest})
            chapter_entries.append({"text": text, "raw": raw, "trimmed": trimmed})
        entries.append(chapter_entries)

    synthesize_missing(jobs, voice)
    for chapter_entries in entries:
        for entry in chapter_entries:
            if force or not entry["trimmed"].exists():
                trim_silence(entry["raw"], entry["trimmed"])
            entry["raw_duration"] = float(probe(entry["trimmed"])["format"]["duration"])

    source_video = next(stream for stream in source_info["streams"] if stream["codec_type"] == "video")
    source_audio = next(stream for stream in source_info["streams"] if stream["codec_type"] == "audio")
    timeline_end = float(source_video["duration"])
    starts = [float(page["start_seconds"]) for page in pages] + [timeline_end]
    total_samples = round(float(source_audio["duration"]) * SAMPLE_RATE)
    master = bytearray(total_samples * 2)
    placements: list[dict[str, Any]] = []
    chapter_stats: list[dict[str, Any]] = []

    for page_index, (chapter, chapter_entries) in enumerate(zip(ENGLISH_CHAPTERS, entries, strict=True)):
        start = starts[page_index]
        end = starts[page_index + 1]
        duration = end - start
        natural_duration = sum(entry["raw_duration"] for entry in chapter_entries) + GAP * (len(chapter_entries) - 1)
        available = duration - LEAD - TAIL
        speed = max(MIN_SPEED, natural_duration / available)
        if speed > MAX_SPEED:
            raise RuntimeError(
                f"Page {page_index + 1} English narration is too long: "
                f"{natural_duration:.2f}s natural / {available:.2f}s slot (speed {speed:.3f})"
            )
        position = start + LEAD
        page_placements: list[dict[str, Any]] = []
        for cue_index, (text, entry) in enumerate(zip(chapter["cues"], chapter_entries, strict=True), 1):
            digest = hashlib.sha256((text + voice["name"] + str(SAPI_RATE)).encode("utf-8")).hexdigest()
            timed = timed_dir / f"p{page_index + 1:02d}_c{cue_index:02d}_{digest[:12]}_{speed:.5f}.wav"
            if force or not timed.exists():
                change_tempo(entry["trimmed"], timed, speed)
            pcm = read_pcm(timed)
            sample_count = len(pcm) // 2
            offset = round(position * SAMPLE_RATE)
            end_offset = offset + sample_count
            if end_offset > total_samples:
                raise RuntimeError("English narration exceeds the source duration")
            master[offset * 2:end_offset * 2] = pcm
            placement = {
                "page": page_index + 1,
                "cue": cue_index,
                "text": text,
                "speech_start": offset / SAMPLE_RATE,
                "speech_end": end_offset / SAMPLE_RATE,
                "tempo": speed,
            }
            placements.append(placement)
            page_placements.append(placement)
            position = end_offset / SAMPLE_RATE + GAP
        trailing = end - page_placements[-1]["speech_end"]
        if trailing > SILENCE_SECONDS:
            raise RuntimeError(f"Page {page_index + 1} would end with {trailing:.2f}s of silence")
        chapter_stats.append({
            "page": page_index + 1,
            "start": start,
            "end": end,
            "natural_duration": natural_duration,
            "tempo": speed,
            "trailing_silence": trailing,
            "cues": len(page_placements),
        })

    placements.sort(key=lambda item: item["speech_start"])
    for previous, current in zip(placements, placements[1:]):
        if current["speech_start"] - previous["speech_end"] > SILENCE_SECONDS:
            raise RuntimeError("English narration would contain a silence longer than three seconds")

    cues: list[dict[str, Any]] = []
    for index, placement in enumerate(placements):
        next_start = placements[index + 1]["speech_start"] if index + 1 < len(placements) else total_samples / SAMPLE_RATE
        cues.append({
            "page": placement["page"],
            "start": round(placement["speech_start"], 3),
            "end": round(min(placement["speech_end"] + 0.10, next_start - 0.03), 3),
            "text": wrap_cue(placement["text"]),
        })

    with wave.open(str(EN_WAV), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(SAMPLE_RATE)
        handle.writeframes(master)
    write_subtitles(cues, EN_SRT, EN_VTT)
    (AUDIO_BUILD / "cues.json").write_text(json.dumps(cues, ensure_ascii=False, indent=2), encoding="utf-8")
    metadata = {
        "engine": voice["engine"],
        "voice": voice["name"],
        "culture": voice["culture"],
        "rate": SAPI_RATE,
        "lead_seconds": LEAD,
        "gap_seconds": GAP,
        "minimum_tail_seconds": TAIL,
        "chapters": chapter_stats,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
    }
    (AUDIO_BUILD / "tts.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return cues, metadata


def extract_chinese_audio() -> None:
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(SOURCE), "-map", "0:a:0",
         "-ar", str(SAMPLE_RATE), "-ac", "1", "-c:a", "pcm_s16le", str(ZH_WAV)])


def normalize_english_audio(duration: float) -> Path:
    normalized = AUDIO_BUILD / "narration_en_normalized.wav"
    # Loudnorm may retain a small look-ahead buffer; add extra tail and let the muxer trim to the video duration.
    filters = f"loudnorm=I=-16:TP=-1.5:LRA=7,apad,atrim=duration={duration + 0.10:.6f}"
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(EN_WAV), "-af", filters,
         "-ar", str(SAMPLE_RATE), "-ac", "1", "-c:a", "pcm_s16le", str(normalized)])
    return normalized


def mux_english(source_info: dict[str, Any]) -> None:
    duration = float(source_info["format"]["duration"])
    normalized = normalize_english_audio(duration)
    temporary = ROOT / "meaning_intelligence_launch_en.tmp.mp4"
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(SOURCE), "-i", str(normalized), "-i", str(ZH_SRT), "-i", str(EN_SRT),
        "-map", "0:v:0", "-map", "1:a:0", "-map", "0:a:0", "-map", "2:s:0", "-map", "3:s:0",
        "-c:v", "copy", "-c:a:0", "aac", "-b:a:0", "192k", "-ar:a:0", str(SAMPLE_RATE), "-ac:a:0", "1",
        "-c:a:1", "copy", "-c:s", "mov_text",
        "-metadata:s:a:0", "language=eng", "-metadata:s:a:0", "title=English narration",
        "-metadata:s:a:1", "language=zho", "-metadata:s:a:1", "title=中文旁白",
        "-disposition:a:0", "default", "-disposition:a:1", "0",
        "-metadata:s:s:0", "language=zho", "-metadata:s:s:0", "title=中文",
        "-metadata:s:s:1", "language=eng", "-metadata:s:s:1", "title=English",
        "-disposition:s:0", "0", "-disposition:s:1", "default",
        "-map_metadata", "0", "-metadata", "title=意义智能 / Meaning Intelligence — English narration",
        "-metadata", "comment=English SAPI narration; verified Chinese video stream preserved; bilingual selectable subtitles",
        "-t", f"{duration:.6f}", "-movflags", "+faststart", str(temporary),
    ]
    run(cmd)
    temporary.replace(EN_VIDEO)


def write_player() -> None:
    PLAYER.write_text("""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Meaning Intelligence — Bilingual Explainer</title>
<style>
:root{color-scheme:dark;--bg:#050e1b;--panel:#0a1b2d;--line:#28465f;--cyan:#59e7d3;--text:#f4f8fc;--muted:#a9bccf}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 75% 10%,#12324a 0,transparent 42%),var(--bg);color:var(--text);font:16px/1.5 "Segoe UI",Arial,sans-serif}
main{width:min(1180px,94vw);margin:36px auto 60px}.eyebrow{color:var(--cyan);font-size:12px;letter-spacing:.22em;text-transform:uppercase;font-weight:700}
h1{font-size:clamp(28px,4vw,52px);line-height:1.08;margin:10px 0 8px}.sub{color:var(--muted);margin:0 0 24px}
.switch{display:flex;gap:10px;flex-wrap:wrap;margin:18px 0}button{border:1px solid var(--line);background:var(--panel);color:var(--text);padding:11px 20px;border-radius:999px;font:inherit;font-weight:650;cursor:pointer}
button.active{background:var(--cyan);border-color:var(--cyan);color:#04211f}button:focus-visible,a:focus-visible{outline:3px solid #63b4ff;outline-offset:3px}
.screen{background:#02060c;border:1px solid var(--line);border-radius:18px;overflow:hidden;box-shadow:0 24px 80px #0008}video{display:block;width:100%;aspect-ratio:16/9;background:#02060c}
.meta{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;padding:14px 18px;background:var(--panel);border-top:1px solid var(--line);color:var(--muted);font-size:14px}
.links{display:flex;gap:18px;flex-wrap:wrap;margin-top:18px}a{color:var(--cyan)}.note{color:var(--muted);font-size:13px;margin-top:22px}code{color:#d7e7f5}
@media(max-width:640px){main{margin-top:22px}.meta{display:block}.meta span{display:block;margin:3px 0}}
</style>
</head>
<body>
<main>
<div class="eyebrow">Illustrated explainer · 11 chapters · 2:34</div>
<h1>Meaning Intelligence<br><span style="color:var(--cyan)">A rudder for intelligence</span></h1>
<p class="sub">Switch between the preserved Chinese narration and the locally synthesized English narration. Subtitles remain selectable in the player.</p>
<div class="switch" role="group" aria-label="Narration language">
<button id="zh" type="button" lang="zh-CN">中文旁白</button>
<button id="en" class="active" type="button" lang="en">English narration</button>
</div>
<div class="screen">
<video id="video" controls playsinline preload="metadata" poster="slides/01.png">
<track id="subtitle" kind="subtitles" src="subtitles.en.vtt" srclang="en" label="English" default>
Your browser does not support HTML video.
</video>
<div class="meta"><span id="status">English narration · 38 subtitle cues</span><span>1920×1080 · H.264 / AAC · 154 s</span></div>
</div>
<div class="links"><a id="download" href="meaning_intelligence_launch_en.mp4" download>Download English MP4</a><a href="subtitles.en.srt" download>English SRT</a><a href="subtitles.en.vtt" download>English VTT</a></div>
<p class="note">Local-only player. For reliable browser subtitle loading, serve this folder with <code>python -m http.server 8000</code> and open <code>http://localhost:8000/player.html</code>. No network assets or deployment are used.</p>
</main>
<script>
const editions={
  en:{video:'meaning_intelligence_launch_en.mp4',track:'subtitles.en.vtt',lang:'en',label:'English',status:'English narration · 38 subtitle cues',download:'Download English MP4'},
  zh:{video:'meaning_intelligence_launch.mp4',track:'subtitles.zh.vtt',lang:'zh-CN',label:'中文',status:'中文旁白 · 38 条字幕',download:'Download Chinese MP4'}
};
const video=document.getElementById('video'),track=document.getElementById('subtitle'),status=document.getElementById('status'),download=document.getElementById('download');
let current='en',resumeAt=0;
function select(language){
  if(language===current && video.currentSrc)return;
  resumeAt=video.currentTime||0;current=language;const e=editions[language];
  document.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.id===language));
  track.src=e.track;track.srclang=e.lang;track.label=e.label;video.src=e.video;status.textContent=e.status;download.href=e.video;download.textContent=e.download;
  video.load();video.addEventListener('loadedmetadata',()=>{video.currentTime=Math.min(resumeAt,video.duration||resumeAt);track.mode='showing';},{once:true});
}
document.getElementById('en').addEventListener('click',()=>select('en'));
document.getElementById('zh').addEventListener('click',()=>select('zh'));
</script>
</body>
</html>
""", encoding="utf-8")


def validate_subtitles(
    cues: list[dict[str, Any]],
    duration: float,
    srt_path: Path = EN_SRT,
    vtt_path: Path = EN_VTT,
    label: str = "English",
) -> dict[str, Any]:
    if not cues:
        raise RuntimeError(f"No {label} subtitle cues")
    previous_end = 0.0
    gaps: list[float] = []
    for cue in cues:
        if cue["start"] < previous_end - 0.001:
            raise RuntimeError(f"Overlapping or out-of-order {label} subtitle cues")
        if cue["end"] <= cue["start"] or cue["end"] > duration + 0.01:
            raise RuntimeError(f"Invalid {label} subtitle timing: {cue}")
        if cue["end"] - cue["start"] < 0.25 or not cue["text"].strip():
            raise RuntimeError(f"{label} subtitle cue too short or empty: {cue}")
        gaps.append(cue["start"] - previous_end)
        previous_end = cue["end"]
    gaps.append(duration - previous_end)
    srt = parse_srt(srt_path)
    if len(srt) != len(cues):
        raise RuntimeError(f"{label} SRT cue count mismatch")
    for expected, actual in zip(cues, srt, strict=True):
        if abs(expected["start"] - actual["start"]) > 0.002 or abs(expected["end"] - actual["end"]) > 0.002:
            raise RuntimeError(f"{label} SRT timing does not match generated audio placements")
    vtt_text = vtt_path.read_text(encoding="utf-8")
    if not vtt_text.startswith("WEBVTT") or vtt_text.count(" --> ") != len(cues):
        raise RuntimeError(f"{label} VTT is malformed")
    return {"cue_count": len(cues), "first_start": cues[0]["start"], "last_end": cues[-1]["end"],
            "max_gap_seconds": round(max(gaps), 3), "overlap_count": 0, "srt_vtt_valid": True}


def extract_embedded_subtitles(path: Path, stream_index: int) -> list[dict[str, Any]]:
    result = subprocess.run([
        "ffmpeg", "-v", "error", "-i", str(path), "-map", f"0:{stream_index}",
        "-c:s", "srt", "-f", "srt", "-",
    ], capture_output=True, text=True, encoding="utf-8", errors="strict", check=True)
    return parse_srt_text(result.stdout)


def analyze_release_audio(path: Path, duration: float, chapter_boundaries: list[float]) -> dict[str, Any]:
    result = subprocess.run([
        "ffmpeg", "-hide_banner", "-nostats", "-i", str(path), "-map", "0:a:0",
        "-af", f"silencedetect=n={SILENCE_DB}dB:d={SILENCE_SECONDS},volumedetect", "-f", "null", "-",
    ], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode:
        raise RuntimeError(f"Audio analysis failed for {path.name}: {result.stderr.strip()}")
    mean_match = re.search(r"mean_volume:\s*([-\d.]+) dB", result.stderr)
    peak_match = re.search(r"max_volume:\s*([-\d.]+) dB", result.stderr)
    if not mean_match or not peak_match:
        raise RuntimeError(f"Could not measure audio levels for {path.name}")
    mean_db = float(mean_match.group(1))
    peak_db = float(peak_match.group(1))
    if mean_db <= -45 or peak_db <= -20:
        raise RuntimeError(f"{path.name} audio appears silent: mean={mean_db}, peak={peak_db}")
    events: list[dict[str, Any]] = []
    open_start: float | None = None
    for line in result.stderr.splitlines():
        start_match = re.search(r"silence_start:\s*([-\d.]+)", line)
        end_match = re.search(r"silence_end:\s*([-\d.]+)", line)
        if start_match:
            open_start = float(start_match.group(1))
        if end_match and open_start is not None:
            end = float(end_match.group(1))
            events.append({"start": open_start, "end": end, "duration": round(end - open_start, 3)})
            open_start = None
    if open_start is not None:
        events.append({"start": open_start, "end": duration, "duration": round(duration - open_start, 3)})
    long_silences = [event for event in events if event["duration"] > SILENCE_SECONDS + 0.01]
    unexplained = [event for event in long_silences if not any(boundary - 0.5 <= event["end"] <= boundary + 1.0 for boundary in chapter_boundaries)]
    transitions = [event for event in long_silences if event not in unexplained]
    if unexplained:
        raise RuntimeError(f"{path.name} audio has unexplained silence over three seconds: {unexplained}")
    return {
        "mean_volume_db": mean_db,
        "max_volume_db": peak_db,
        "silence_threshold_db": SILENCE_DB,
        "silence_threshold_seconds": SILENCE_SECONDS,
        "silence_events_over_3_seconds": long_silences,
        "chapter_transition_silences_over_3_seconds": transitions,
        "unexplained_silence_events_over_3_seconds": unexplained,
    }


def release_narration(cues: list[dict[str, Any]]) -> list[str]:
    lines: list[str] = []
    for chapter in RELEASE_CHAPTERS:
        chapter_cues = [cue for cue in cues if chapter["start"] <= cue["start"] < chapter["end"]]
        lines.extend([
            f"{chapter['number']:02d}  {chapter['title_zh']} / {chapter['title_en']}",
            f"[{srt_time(chapter['start'])}–{srt_time(chapter['end'])}]",
            " ".join(cue["text"].replace("\n", " ").strip() for cue in chapter_cues),
            "",
        ])
    return lines


def verify_current_release() -> dict[str, Any]:
    edition_paths = {"zh": RELEASE_ZH, "en": RELEASE_EN}
    expected_cue_counts = {"zho": 41, "eng": 44}
    edition_reports: dict[str, Any] = {}
    embedded: dict[str, dict[str, list[dict[str, Any]]]] = {}
    video_hashes: dict[str, str] = {}

    for edition, path in edition_paths.items():
        if not path.is_file():
            raise RuntimeError(f"Missing current release master: {path}")
        digest = sha256(path)
        if digest != RELEASE_HASHES[path.name]:
            raise RuntimeError(f"Current release master hash changed: {path.name}")
        info = probe(path)
        duration = float(info["format"]["duration"])
        if abs(duration - RELEASE_DURATION) > 0.002:
            raise RuntimeError(f"{path.name} duration is not the verified 164.010667 seconds: {duration}")
        streams = info["streams"]
        video = next(stream for stream in streams if stream["codec_type"] == "video")
        audios = [stream for stream in streams if stream["codec_type"] == "audio"]
        subtitles = [stream for stream in streams if stream["codec_type"] == "subtitle"]
        if video["codec_name"] != "h264" or (video["width"], video["height"]) != (1920, 1080):
            raise RuntimeError(f"{path.name} is not H.264 1920x1080")
        if video["r_frame_rate"] != "24/1" or int(video["nb_frames"]) != 3936:
            raise RuntimeError(f"{path.name} is not 24 fps with 3936 frames")
        if len(audios) != 1 or audios[0]["codec_name"] != "aac" or int(audios[0]["sample_rate"]) != 48000 or audios[0]["channels"] != 2:
            raise RuntimeError(f"{path.name} does not contain the expected AAC 48 kHz stereo track")
        if len(subtitles) != 2 or {stream.get("tags", {}).get("language") for stream in subtitles} != {"zho", "eng"}:
            raise RuntimeError(f"{path.name} is missing selectable Chinese and English subtitles")
        if any(stream["codec_name"] != "mov_text" for stream in subtitles):
            raise RuntimeError(f"{path.name} embedded subtitles are not mov_text")

        chapters = info.get("chapters", [])
        if len(chapters) != len(RELEASE_CHAPTERS):
            raise RuntimeError(f"{path.name} chapter count is not 12")
        for actual, expected in zip(chapters, RELEASE_CHAPTERS, strict=True):
            if abs(float(actual["start_time"]) - expected["start"]) > 0.01 or abs(float(actual["end_time"]) - expected["end"]) > 0.01:
                raise RuntimeError(f"{path.name} chapter {expected['number']} boundary mismatch")

        decode = subprocess.run([
            "ffmpeg", "-v", "error", "-xerror", "-i", str(path), "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-",
        ], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if decode.returncode:
            raise RuntimeError(f"{path.name} full decode failed: {decode.stderr.strip()}")
        audio_report = analyze_release_audio(path, duration, [chapter["end"] for chapter in RELEASE_CHAPTERS[:-1]])
        video_hash = stream_hash(path, "0:v:0")
        video_hashes[edition] = video_hash
        embedded[edition] = {}
        subtitle_reports: list[dict[str, Any]] = []
        for subtitle in subtitles:
            language = subtitle["tags"]["language"]
            cues = extract_embedded_subtitles(path, int(subtitle["index"]))
            if len(cues) != expected_cue_counts[language]:
                raise RuntimeError(f"{path.name} {language} subtitle cue count mismatch: {len(cues)}")
            embedded[edition][language] = cues
            subtitle_reports.append({
                "index": int(subtitle["index"]),
                "language": language,
                "codec_name": subtitle["codec_name"],
                "nb_frames": int(subtitle["nb_frames"]),
                "duration": subtitle.get("duration"),
                "cue_count": len(cues),
            })
        edition_reports[edition] = {
            "path": path.name,
            "sha256": digest,
            "size_bytes": path.stat().st_size,
            "duration_seconds": duration,
            "video": {key: video.get(key) for key in ("codec_name", "profile", "width", "height", "pix_fmt", "r_frame_rate", "nb_frames", "bit_rate", "duration")},
            "audio": [{**{key: stream.get(key) for key in ("codec_name", "sample_rate", "channels", "channel_layout", "bit_rate", "duration")},
                       "language": stream.get("tags", {}).get("language")} for stream in audios],
            "subtitles": subtitle_reports,
            "chapters": [{"number": chapter["number"], "start_seconds": float(actual["start_time"]),
                          "end_seconds": float(actual["end_time"]), "title_zh": chapter["title_zh"],
                          "title_en": chapter["title_en"]}
                         for actual, chapter in zip(chapters, RELEASE_CHAPTERS, strict=True)],
            "video_stream_sha256": video_hash,
            "full_decode_passed": True,
            **audio_report,
        }

    if video_hashes["zh"] != video_hashes["en"]:
        raise RuntimeError("Chinese and English editions do not share the same video stream")
    if embedded["zh"] != embedded["en"]:
        raise RuntimeError("Chinese and English editions contain different bilingual subtitle tracks")

    subtitle_paths = {
        "zho": (ZH_SRT, ZH_VTT),
        "eng": (EN_SRT, EN_VTT),
    }
    for language, cues in embedded["zh"].items():
        write_subtitles(cues, *subtitle_paths[language])
        validate_subtitles(cues, RELEASE_DURATION, *subtitle_paths[language], label=language)

    narration_paths = {"zho": ROOT / "narration_zh.txt", "eng": ROOT / "narration_en.txt"}
    for language, cues in embedded["zh"].items():
        header = ["意义智能 / Meaning Intelligence — Illustrated Explainer",
                  f"Narration: {'zh' if language == 'zho' else 'en'}", ""]
        narration_paths[language].write_text("\n".join(header + release_narration(cues)), encoding="utf-8")

    chapters: list[dict[str, Any]] = []
    for chapter in RELEASE_CHAPTERS:
        record = dict(chapter)
        record["duration_seconds"] = chapter["end"] - chapter["start"]
        for language, cues in embedded["zh"].items():
            selected = [cue for cue in cues if chapter["start"] <= cue["start"] < chapter["end"]]
            record[f"narration_{'zh' if language == 'zho' else 'en'}"] = " ".join(cue["text"].replace("\n", " ") for cue in selected)
            record[f"cue_count_{'zh' if language == 'zho' else 'en'}"] = len(selected)
        chapters.append(record)

    manifest: dict[str, Any] = {
        "schema": "meaning-intelligence-release-video-manifest-v2",
        "title": "意义智能 / Meaning Intelligence — Illustrated Explainer",
        "language": "zh-CN / en-US",
        "languages": ["zh-CN", "en-US"],
        "duration_seconds": RELEASE_DURATION,
        "chapter_count": len(chapters),
        "chapters": chapters,
        "videos": [{"language": language, "path": name, "sha256": RELEASE_HASHES[name],
                    "size_bytes": edition_reports[language]["size_bytes"]}
                   for language, name in (("zh", RELEASE_ZH.name), ("en", RELEASE_EN.name))],
        "subtitles": {language: {"srt": srt.name, "vtt": vtt.name} for language, (srt, vtt) in subtitle_paths.items()},
        "narration": {language: path.name for language, path in narration_paths.items()},
        "build_command": "python build_video.py --verify-release",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "verification": "build/verification.json",
    }
    manifest_text = json.dumps(manifest, ensure_ascii=False, indent=2)
    (ROOT / "manifest.json").write_text(manifest_text, encoding="utf-8")
    (ROOT / "chapter_manifest.json").write_text(manifest_text, encoding="utf-8")

    subtitle_report: dict[str, Any] = {}
    for language, cues in embedded["zh"].items():
        srt_path, vtt_path = subtitle_paths[language]
        checked = validate_subtitles(cues, RELEASE_DURATION, srt_path, vtt_path, label=language)
        subtitle_report[language] = {
            **checked,
            "srt": {"path": srt_path.name, "sha256": sha256(srt_path), "size_bytes": srt_path.stat().st_size},
            "vtt": {"path": vtt_path.name, "sha256": sha256(vtt_path), "size_bytes": vtt_path.stat().st_size},
            "identical_in_both_editions": True,
        }
    support_files = [*subtitle_paths["zho"], *subtitle_paths["eng"], *narration_paths.values(), ROOT / "chapter_manifest.json", ROOT / "manifest.json"]
    for name, expected in RELEASE_HASHES.items():
        if sha256(edition_paths["zh" if name == RELEASE_ZH.name else "en"]) != expected:
            raise RuntimeError(f"Current release master changed during verification: {name}")
    report: dict[str, Any] = {
        "schema": "meaning-intelligence-release-video-verification-v2",
        "ok": True,
        "verified_utc": datetime.now(timezone.utc).isoformat(),
        "duration_seconds": RELEASE_DURATION,
        "chapter_count": len(chapters),
        "editions": edition_reports,
        "subtitles": subtitle_report,
        "narration": {language: {"path": path.name, "sha256": sha256(path), "size_bytes": path.stat().st_size}
                      for language, path in narration_paths.items()},
        "chapter_manifest": {"path": "chapter_manifest.json", "sha256": sha256(ROOT / "chapter_manifest.json"),
                             "size_bytes": (ROOT / "chapter_manifest.json").stat().st_size},
        "support_files": [{"path": path.name, "sha256": sha256(path), "size_bytes": path.stat().st_size} for path in support_files],
        "checks": {
            "duration_over_120": True,
            "h264_1920x1080_24fps": True,
            "frame_count_3936": True,
            "aac_48khz_stereo": True,
            "twelve_contiguous_chapters": True,
            "full_decode": True,
            "audio_non_silent": True,
            "no_unexplained_silence_over_3_seconds": True,
            "bilingual_mov_text_subtitles": True,
            "subtitle_tracks_identical_across_editions": True,
            "video_stream_identical_across_editions": True,
            "master_hashes_verified": True,
            "external_subtitle_vtt_and_narration_match": True,
        },
    }
    VERIFICATION.parent.mkdir(parents=True, exist_ok=True)
    VERIFICATION.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Verified current release: {RELEASE_DURATION:.6f}s, 1920x1080, 24 fps, 3936 frames, 12 chapters; "
          f"41 Chinese and 44 English cues; both editions fully decoded.", flush=True)
    return report


def verify(update_manifest: bool = True) -> dict[str, Any]:
    if sha256(SOURCE) != SOURCE_SHA256:
        raise RuntimeError("Verified Chinese source MP4 hash changed; refusing to continue")
    source_info = probe(SOURCE)
    english_info = probe(EN_VIDEO)
    source_video = next(stream for stream in source_info["streams"] if stream["codec_type"] == "video")
    source_audio = next(stream for stream in source_info["streams"] if stream["codec_type"] == "audio")
    video = next(stream for stream in english_info["streams"] if stream["codec_type"] == "video")
    audios = [stream for stream in english_info["streams"] if stream["codec_type"] == "audio"]
    subtitles = [stream for stream in english_info["streams"] if stream["codec_type"] == "subtitle"]
    duration = float(english_info["format"]["duration"])
    if duration <= 120:
        raise RuntimeError("English video is not longer than 120 seconds")
    if video["codec_name"] != "h264" or (video["width"], video["height"]) != (1920, 1080):
        raise RuntimeError("English video does not preserve H.264 1920x1080")
    if video["r_frame_rate"] != "30/1" or int(video["nb_frames"]) != 4620:
        raise RuntimeError("English video frame rate or frame count changed")
    if len(audios) != 2 or audios[0]["codec_name"] != "aac" or int(audios[0]["sample_rate"]) != 48000 or audios[0]["channels"] != 1:
        raise RuntimeError("English AAC stream is missing or has unexpected properties")
    if audios[1]["codec_name"] != "aac" or int(audios[1]["sample_rate"]) != 48000 or audios[1]["channels"] != 1:
        raise RuntimeError("Preserved Chinese audio track is missing")
    if len(subtitles) != 2 or {stream.get("tags", {}).get("language") for stream in subtitles} != {"eng", "zho"}:
        raise RuntimeError("Bilingual selectable subtitle tracks are missing")
    if any(stream["codec_name"] != "mov_text" for stream in subtitles):
        raise RuntimeError("Embedded subtitles are not mov_text")

    media = run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(EN_VIDEO), "-map", "0:a:0",
                 "-af", f"silencedetect=n={SILENCE_DB}dB:d={SILENCE_SECONDS},volumedetect", "-f", "null", "-"], capture_output=True)
    mean_match = re.search(r"mean_volume:\s*([-\d.]+) dB", media.stderr)
    peak_match = re.search(r"max_volume:\s*([-\d.]+) dB", media.stderr)
    if not mean_match or not peak_match:
        raise RuntimeError("Could not measure English audio levels")
    mean_db = float(mean_match.group(1))
    peak_db = float(peak_match.group(1))
    if mean_db <= -45 or peak_db <= -20:
        raise RuntimeError(f"English audio appears silent: mean={mean_db}, peak={peak_db}")
    silence_events: list[dict[str, Any]] = []
    open_start: float | None = None
    for line in media.stderr.splitlines():
        start_match = re.search(r"silence_start:\s*([-\d.]+)", line)
        end_match = re.search(r"silence_end:\s*([-\d.]+)", line)
        if start_match:
            open_start = float(start_match.group(1))
        if end_match and open_start is not None:
            end = float(end_match.group(1))
            silence_events.append({"start": open_start, "end": end, "duration": round(end - open_start, 3)})
            open_start = None
    if open_start is not None:
        silence_events.append({"start": open_start, "end": duration, "duration": round(duration - open_start, 3)})
    long_silences = [event for event in silence_events if event["duration"] > SILENCE_SECONDS + 0.01]
    if long_silences:
        raise RuntimeError(f"English audio has silence over three seconds: {long_silences}")

    cues = parse_srt(EN_SRT)
    subtitle_check = validate_subtitles(cues, duration)
    source_video_hash = stream_hash(SOURCE, "0:v:0")
    english_video_hash = stream_hash(EN_VIDEO, "0:v:0")
    source_audio_hash = stream_hash(SOURCE, "0:a:0")
    english_chinese_audio_hash = stream_hash(EN_VIDEO, "0:a:1")
    video_stream_preserved = source_video_hash == english_video_hash
    chinese_audio_stream_preserved = source_audio_hash == english_chinese_audio_hash
    if not video_stream_preserved or not chinese_audio_stream_preserved:
        raise RuntimeError("Copied Chinese video or audio stream does not match the verified source")
    if sha256(SOURCE) != SOURCE_SHA256:
        raise RuntimeError("Chinese source changed during verification")

    report: dict[str, Any] = {
        "verified_utc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "path": str(SOURCE), "sha256": SOURCE_SHA256, "preserved": True,
            "duration_seconds": float(source_info["format"]["duration"]),
            "video": {key: source_video.get(key) for key in ("codec_name", "width", "height", "r_frame_rate", "nb_frames", "duration")},
            "audio": {key: source_audio.get(key) for key in ("codec_name", "sample_rate", "channels", "duration")},
        },
        "english": {
            "path": str(EN_VIDEO), "sha256": sha256(EN_VIDEO),
            "duration_seconds": duration, "size_bytes": int(english_info["format"]["size"]),
            "video": {key: video.get(key) for key in ("codec_name", "profile", "width", "height", "pix_fmt", "r_frame_rate", "nb_frames", "bit_rate", "duration")},
            "audio": [{**{key: stream.get(key) for key in ("codec_name", "sample_rate", "channels", "channel_layout", "bit_rate", "duration")},
                       "language": stream.get("tags", {}).get("language"),
                       "title": stream.get("tags", {}).get("title") or stream.get("tags", {}).get("name")} for stream in audios],
            "subtitles": [{**{key: stream.get(key) for key in ("codec_name", "duration", "nb_frames")},
                           "language": stream.get("tags", {}).get("language"),
                           "title": stream.get("tags", {}).get("title") or stream.get("tags", {}).get("name"),
                           "disposition": stream.get("disposition")} for stream in subtitles],
            "video_stream_sha256": english_video_hash,
            "preserved_chinese_audio_stream_sha256": english_chinese_audio_hash,
            "mean_volume_db": mean_db, "max_volume_db": peak_db,
            "silence_threshold_db": SILENCE_DB, "silence_threshold_seconds": SILENCE_SECONDS,
            "silence_events_over_3_seconds": long_silences,
        },
        "subtitles": subtitle_check,
        "checks": {
            "duration_over_120": True, "h264_1920x1080_30fps": True, "video_stream_preserved": video_stream_preserved,
            "chinese_audio_stream_preserved": chinese_audio_stream_preserved,
            "aac_48khz_mono": True, "audio_non_silent": True, "no_silence_over_3_seconds": True,
            "english_srt_vtt_valid": True, "bilingual_embedded_subtitles": True,
            "chinese_source_hash_unchanged": True,
        },
    }
    VERIFICATION.parent.mkdir(parents=True, exist_ok=True)
    VERIFICATION.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if update_manifest:
        update_release_manifest(report)
    print(
        f"Verified English edition: {duration:.6f}s, {video['width']}x{video['height']}, "
        f"{video['r_frame_rate']} fps, {video['nb_frames']} frames; English AAC "
        f"{audios[0]['sample_rate']} Hz {audios[0]['channel_layout']}; audio {mean_db:.1f}..{peak_db:.1f} dB; "
        f"{len(cues)} cues; silences >3s: {len(long_silences)}.",
        flush=True,
    )
    return report


def update_release_manifest(report: dict[str, Any]) -> None:
    path = ROOT / "manifest.json"
    manifest = json.loads(path.read_text(encoding="utf-8"))
    tts_path = AUDIO_BUILD / "tts.json"
    tts = json.loads(tts_path.read_text(encoding="utf-8")) if tts_path.exists() else {}
    manifest["title"] = "意义智能：给智能装上方向舵 / Meaning Intelligence: A Rudder for Intelligence"
    manifest["language"] = "zh-CN / en-US"
    manifest["languages"] = ["zh-CN", "en-US"]
    manifest["generated_at_utc"] = datetime.now(timezone.utc).isoformat()
    manifest["build_command"] = "python build_video.py"
    manifest["script"] = str(Path(__file__).resolve())
    manifest["source_video_sha256"] = SOURCE_SHA256
    outputs = manifest.setdefault("outputs", {})
    outputs.update({
        "english_video": str(EN_VIDEO),
        "english_subtitles_srt": str(EN_SRT),
        "english_subtitles_vtt": str(EN_VTT),
        "chinese_subtitles_srt": str(ZH_SRT),
        "chinese_subtitles_vtt": str(ZH_VTT),
        "english_narration_text": str(ROOT / "narration_en.txt"),
        "english_narration_wav": str(EN_WAV),
        "chinese_narration_text": str(ROOT / "narration_zh.txt"),
        "chinese_narration_wav": str(ZH_WAV),
        "player": str(PLAYER),
        "verification": str(VERIFICATION),
    })
    manifest["english_video"] = report["english"]
    manifest.setdefault("tts", {})["english"] = {
        "requested_provider": "local Windows SAPI",
        "actual_provider": tts.get("engine", "Windows SAPI / System.Speech"),
        "voice": tts.get("voice", "Microsoft Zira Desktop"),
        "culture": tts.get("culture", "en-US"),
        "rate": tts.get("rate", SAPI_RATE),
        "network_used": False,
        "videogen_used": False,
    }
    for page, chapter in zip(manifest.get("pages", []), ENGLISH_CHAPTERS, strict=True):
        page["title_en"] = chapter["title_en"]
        page["narration_en"] = " ".join(chapter["cues"])
        page["english_cue_count"] = len(chapter["cues"])
    manifest.setdefault("validation", {})["english_edition"] = report
    manifest["validation"]["passed"] = True
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    # Keep the secondary manifest consistent with the actual 11-page release, not the obsolete draft.
    (ROOT / "chapter_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--verify-release", action="store_true", help="verify the current 164-second bilingual release (default)")
    mode.add_argument("--build-legacy", action="store_true", help="build the obsolete 154-second English-dubbing edition")
    mode.add_argument("--verify-only", action="store_true", help="verify the legacy English-dubbing edition")
    parser.add_argument("--force-audio", action="store_true", help="with --build-legacy, regenerate local SAPI audio even when cached")
    args = parser.parse_args()
    if args.force_audio and not args.build_legacy:
        parser.error("--force-audio requires --build-legacy")
    for executable in ("ffmpeg", "ffprobe"):
        if shutil.which(executable) is None:
            raise RuntimeError(f"Missing required executable: {executable}")
    if not (args.build_legacy or args.verify_only):
        verify_current_release()
        return

    if shutil.which("powershell.exe") is None:
        raise RuntimeError("Missing required executable: powershell.exe")
    if not SOURCE.exists():
        raise RuntimeError(f"Missing verified Chinese source: {SOURCE}")
    if sha256(SOURCE) != SOURCE_SHA256:
        raise RuntimeError("Verified Chinese source SHA-256 does not match; refusing to modify deliverables")
    if args.verify_only:
        verify()
        return

    AUDIO_BUILD.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    source_info = probe(SOURCE)
    chinese_cues = parse_srt(ROOT / "meaning_intelligence_launch.zh.srt")
    write_subtitles(chinese_cues, ZH_SRT, ZH_VTT)
    write_narration(manifest)
    extract_chinese_audio()
    build_english_audio(manifest, source_info, args.force_audio)
    mux_english(source_info)
    write_player()
    verify()
    print(f"DONE (legacy): {EN_VIDEO}", flush=True)


if __name__ == "__main__":
    main()
