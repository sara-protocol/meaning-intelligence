# -*- coding: utf-8 -*-
"""Windows SAPI 合成英文七章语音 -> ffmpeg 合并 -> 字符比例句级字幕"""
import os, re, json, subprocess, wave

WS = r"C:\Users\gog98\Documents\lingxi-claw\users\247656584\projects\11955814199197869\workspace\意义智能"
PUB = os.path.join(WS, "意义智能有声读物_发布包")
EN_ASSETS = os.path.join(PUB, "assets_en")
os.makedirs(EN_ASSETS, exist_ok=True)

script = open(os.path.join(WS, "en_script.txt"), encoding="utf-8").read()
chapters = [c.strip() for c in script.split("@@SEP@@") if len(c.strip()) > 200]
print("章节脚本数:", len(chapters))
assert len(chapters) == 7

import win32com.client
v = win32com.client.Dispatch("SAPI.SpVoice")
for tok in v.GetVoices():
    if "English" in tok.GetDescription():
        v.Voice = tok
        break
v.Rate = 1  # 稍快，接近讲解语速

def sent_split(text):
    parts = re.split(r"(?<=[.?!])\s+", text)
    cues, buf = [], ""
    for p in parts:
        if len(buf) + len(p) < 95:
            buf = (buf + " " + p).strip()
        else:
            if buf: cues.append(buf)
            buf = p
    if buf: cues.append(buf)
    return cues

ch_files, ch_cues = [], []
for i, ch in enumerate(chapters):
    wav = os.path.join(EN_ASSETS, f"ch{i}.wav")
    if not os.path.exists(wav):
        # 流式写wav
        stream = win32com.client.Dispatch("SAPI.SpFileStream")
        stream.Format.Type = 39
        stream.Open(wav, 3)  # SSFMCreateForWrite
        v.AudioOutputStream = stream
        v.Speak(ch)
        stream.Close()
        v.AudioOutputStream = None
    with wave.open(wav, "rb") as w:
        d = w.getnframes() / w.getframerate()
    print(f"ch{i} 时长 {d:.1f}s")
    ch_files.append(wav)
    # 字符比例分配句时间
    cues = sent_split(ch)
    total = sum(len(c) for c in cues) or 1
    t = 0.0
    for c in cues:
        dd = d * len(c) / total
        ch_cues.append({"s": round(t, 2), "e": round(t + dd, 2), "t": c})
        t += dd

# ---- 合并 ----
lst = os.path.join(EN_ASSETS, "list.txt")
with open(lst, "w", encoding="utf-8") as f:
    for w in ch_files:
        f.write(f"file '{w}'\n")
mp3 = os.path.join(EN_ASSETS, "audio_en.mp3")
subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst,
                "-ar", "22050", "-ac", "1", "-c:a", "libmp3lame", "-b:a", "64k", mp3],
               capture_output=True, check=True)
print("audio_en.mp3:", os.path.getsize(mp3)//1024//1024, "MB")

offsets, t = [], 0.0
for w in ch_files:
    with wave.open(w, "rb") as ww:
        d = ww.getnframes() / ww.getframerate()
    offsets.append(t)
    t += d
total = t
en_cues = []
for i, c in enumerate(ch_cues):
    pass
en_cues = []
idx = 0
for i, ch in enumerate(chapters):
    cues = sent_split(ch)
    for c in cues:
        cc = ch_cues[idx]; idx += 1
        en_cues.append({"s": round(cc["s"] + offsets[i], 2), "e": round(cc["e"] + offsets[i], 2), "t": c["t"]})
for i in range(1, len(en_cues)):
    if en_cues[i]["s"] < en_cues[i - 1]["e"] - 0.05:
        en_cues[i - 1]["e"] = en_cues[i]["s"]
json.dump(en_cues, open(os.path.join(PUB, "subtitles_en.json"), "w", encoding="utf-8"), ensure_ascii=False)
print("英文字幕条数:", len(en_cues), "总长 %.1f min" % (total/60))

names = ["Chapter 1 · Why We Need Meaning Intelligence Now",
 "Chapter 2 · The Core Theoretical System",
 "Chapter 3 · Mechanisms and Engineering",
 "Chapter 4 · Multi-Scale, Multi-Domain Practice",
 "Chapter 5 · Civilizational Evolution and Outlook",
 "Appendix · Tools and Research Support",
 "Full-Book Summary · A Rudder for Intelligence"]
json.dump({"total": round(total, 1),
           "chapters": [{"t": round(o, 1), "n": n} for o, n in zip(offsets, names)]},
          open(os.path.join(PUB, "timeline_en.json"), "w", encoding="utf-8"), ensure_ascii=False)
for o, n in zip(offsets, names): print(round(o, 1), n)
